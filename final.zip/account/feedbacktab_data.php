 <?php include 'connect.php';

			$result1 = mysqli_query($con,"SELECT `firstname` FROM `users` WHERE `type`= 'employee'");
			
			$result2 = mysqli_query($con,"SELECT `id` FROM `users` WHERE `type`= 'employee'");
			
			$result3 = mysqli_query($con,"SELECT `id` FROM `users` WHERE `type`= 'employer'");

?>		 
		 