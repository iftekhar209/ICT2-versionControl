<?php 

 

 $servername_access = "localhost";
 $username_access = "remotework";
 $password_access ="Advanced@18";
 $dbname ="remotework"; 
/*
 $servername_access = "localhost";
 $username_access = "workdisk";
 $password_access ="Advanced@18";
 $dbname ="workdisk";   */ 
 
 
 
 // Create connection
$con = mysqli_connect($servername_access, $username_access, $password_access, $dbname);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

 
 ?>

