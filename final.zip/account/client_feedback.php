<?php
   @session_start();

  if(isset($_SESSION['UserName']) && isset($_SESSION['Email']))
	 {
				 $UserName = $_SESSION['UserName'];
				 $Email= $_SESSION['Email'];
				
				 
				   $_SESSION['UserName'] =$UserName;
                   $_SESSION['Email'] =$Email;
					
	}
				
	else 
	{  
				 header('location: ../login.php');
	}
			
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	
	<link rel="icon" type="image/png" href="../images/favicon.png">
	<meta http-equiv="Refresh" content="3;url=employeer" />
    
	<title> Employeer Dashboard</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS  
      
	-->
	<link href="assets/css/custom.css" rel="stylesheet"/>
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>
    
	
	<link href="assets/css/jquery.fileupload.css" rel="stylesheet"/>
    <link href="assets/css/jquery.fileupload-ui.css" rel="stylesheet"/>
     
	 
	 

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
    <style>
	  
			  .controls label {
			display: inline-block;
			width: 90px;
			height: 20px;
			text-align: center;
			vertical-align: top;
			padding-top: 40px;
		}
		.controls input {
			display: block;
			margin: 0 auto -40px;
		}
	  
	</style>
	  
	<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>  
	  
   	  
	  
	<script>
    $(document).ready(function() 
	{
        function disableBack() 
		{ window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt)
		{ 
		   if (evt.persisted) disableBack() 
		}
    });
   </script>
	
    <link href="assets/css/style.min.css" rel="stylesheet" /> 
	<link href="assets/css/style-responsive.min.css" rel="stylesheet" />
	<link href="assets/css/theme/default.css" rel="stylesheet" id="theme" />
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
	<link href="assets/plugins/bootstrap-wizard/css/bwizard.min.css" rel="stylesheet" />
	<link href="assets/plugins/parsley/src/parsley.css" rel="stylesheet" />
	<!-- ================== END PAGE LEVEL STYLE ================== -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	
	<!-- ================== END BASE JS ================== -->  
	 
   <!-- <script type="text/javascript" src="../js/validation.js"></script> 
	<script type="text/javascript" src="../js/alertify.min.js"></script> 
	<link rel="stylesheet" href="../css/alertify.core2.css">
	<link rel="stylesheet" href="../css/alertify.default.css"> -->
  
</head>

<body>
    
    
</body>
<div class="row">

    <div class="col-md-12" style="background-color: #088895;padding: 20px;">
        <?php
		
		     include 'connect.php';
		
             if (isset($_POST['submit'])) 
				{    
									
					if (empty($_POST['fbjtitle']) || empty($_POST['fbename']) || empty($_POST['fbeid']) || empty($_POST['fbemployer_id']) || empty($_POST['fbdesc'])) 
						  
					{
						$error = "Details are invalid";
						echo"$error";
										
					}
									
					else
						{
									 
							$title=$_POST['fbjtitle'];							
							$emp_name=$_POST['fbename'];
							$emp_id= $_POST['fbeid'];
							$emplr_id= $_POST['fbemployer_id'];
							$rating=$_POST['rating'];
							$desc=$_POST['fbdesc'];
							
													 
							$query= "INSERT INTO `feedback`(`job_title`, `employee_name`, `f_employee_id`,`f_employer_id`, `rating`, `feedback_desc`)
				  	                       VALUES ('".$title."','".$emp_name."', '".$emp_id."', '".$emplr_id."','".$rating."','".$desc."')";
							
							
							          $con->query($query) or die("Error : ".mysqli_error($con));
													  
							              echo"<h3 style='text-align:center;color: #fff;'> Thank you for your feedback!</h3> "; 
						}						  

				}				
				
				else{
										
							echo"Error";
										
					}
					
			mysqli_close($con);		
								  
		?>                
            
     </div>
    </div>