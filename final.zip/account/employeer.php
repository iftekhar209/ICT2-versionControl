<?php 
@session_start();



    if(isset($_SESSION['UserName']) && isset($_SESSION['Email'])  && isset($_SESSION['type']) && isset($_SESSION['employeer'])  )
	 {
				 $UserName = $_SESSION['UserName'];
				 $Email= $_SESSION['Email'];
				  $type= $_SESSION['type'];
				 
				   $_SESSION['UserName'] =$UserName;
                   $_SESSION['Email'] =$Email;
				
	}
				
	else 
	{  
				// header('location: ../login.php');
				
                session_destroy(); //destroy the session
                header("location:../login.php"); //to redirect back to "index.php" after logging out
                exit();
	}
			 
  
			 
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	
	<link rel="icon" type="image/png" href="../images/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title> Employeer Dashboard</title>

		<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

 
	<link href="assets/css/custom.css" rel="stylesheet"/>
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>
    
	
	

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />
    
    
        <!--  star rating     -->
        
    <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-star-rating/4.0.2/css/star-rating.min.css" />
    


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
   
    <style>
	  
			  .controls label {
			display: inline-block;
			width: 90px;
			height: 20px;
			text-align: center;
			vertical-align: top;
			padding-top: 40px;
		}
		.controls input {
			display: block;
			margin: 0 auto -40px;
		}
	  
	</style>
	
	
	  
	<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>  
	
	
	
    <link href="assets/css/style.min.css" rel="stylesheet" /> 
	<link href="assets/css/style-responsive.min.css" rel="stylesheet" />
	<link href="assets/css/theme/default.css" rel="stylesheet" id="theme" />
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
	<link href="assets/plugins/bootstrap-wizard/css/bwizard.min.css" rel="stylesheet" />
	<link href="assets/plugins/parsley/src/parsley.css" rel="stylesheet" />
	<!-- ================== END PAGE LEVEL STYLE ================== -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	
	<!-- ================== END BASE JS ================== -->  
	
  
</head>
<body>
    <div class="wrapper">
        <div class="sidebar" style='background-color:#303840;width:250px;' >

   
    	    <div class="sidebar-wrapper">
                <div class="logo">
                  <a href="#" class="simple-text">
                   Employer Dashboard
                    </a>
                </div>

            <ul class="nav">
              
              	<!--   
              
				<li class="active"><a data-toggle="tab" href="#AddServices"><i class="pe-7s-upload"></i>
                        <p>Add Services</p></a></li>
                        --> 
						
			    <li class="active"><a data-toggle="tab" href="#AddJob"><i class="pe-7s-upload"></i>
                        <p>Add Job</p></a></li>		
					
				<li><a data-toggle="tab" href="#MyProfile"> <i class="pe-7s-user"></i>
                        <p>My Profile</p></a></li>
				
               <!-- <li> <a href="#" data-toggle="modal" data-target="#myModal"><i class="pe-7s-user"></i>
                        <p>My Profile</p></a></li>	-->			
				<li><a data-toggle="tab" href="#Feedbacktab"><i class="pe-7s-config"></i>
                        <p>Feedback</p></a></li> 
                        
				<li><a data-toggle="tab" href="#EditProfile"><i class="pe-7s-config"></i>
                        <p>Edit Profile</p></a></li> 
				
            </ul>
    	</div>
    	
        </div>

        <div class="main-panel">
                <nav class="navbar navbar-default navbar-fixed">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="#">Dashboard</a>
                        </div>
                        <div class="collapse navbar-collapse">
                            
        
                            <ul class="nav navbar-nav navbar-right">
                                
        						<li>
                                    <a href="#">
                                       <i class="pe-7s-user" style="font-size: 28px;float: left;margin-right: 5px;line-height: 30px;width: 30px;text-align: center;    margin-top: -6px;"></i> <?php echo"$UserName"; ?>
        							   
                                    </a>
                                </li>
        						
        						
                                <li>
                                    <a href="logout">
        							<i class="pe-7s-back" style="font-size: 28px;float: left;margin-right: 5px;line-height: 30px;width: 30px;text-align: center;    margin-top: -6px;"></i> Logout
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
        <div class="content">
        <div class="container-fluid">
        <div class="tab-content">
   
 <!-- post close -->
  
        <div id="AddServices" class="tab-pane fade in active">
        		
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-inverse">
                                <div class="panel-heading">
                                    <h2 class="panel-title" style="font-size:20px;">Add Service</h2>
                                </div>
                                <div class="panel-body">
                                    
                                   <form class="reg-page" name='addservices' enctype="multipart/form-data" action='addservices' method='post' onsubmit="return confirm('Please Check the details brfore submition, You can not modify it!');">
                                       
                                       <div class="row" style="margin-bottom: 30px;">

                                        <div class="col-sm-5">
                                        <label>Service Title *</label>
                                        
                                        <input class='form-control' name='stitle'  type='text' style='text-align:center;' placeholder='Title' required>
                                        </div>
                                        
                                            <div class="col-sm-offset-2 col-sm-5">
                                        <label>Service Description *</label>
                                        
                                          <textarea class='form-control' name='sdescs' style='text-align:center;' required ></textarea>
                                         
                                        </div>
                                        </div>
                                        
                                        
                                        
                                        <div class="row" style="margin-bottom: 30px;">  
                                        
                                        <div class=" col-sm-5">
                                        <label>Service Icon *</label>
                                        
                                            <select name='icon' class="form-control" required>
                                         <option>Choose Icon</option>
                                         <option value="fa fa-desktop">Application Development</option>
                                         <option value="fa fa-bank">Banking</option>
                                         <option value="fa fa-users">Staffing</option>
                                         <option value="fa fa-bar-chart">Sales & marketing</option>
                                         <option value="fa fa-suitcase">Management</option>
                                         <option value="fa fa-cogs">Digital Marking</option>
                                        
                                        </select>
                                         
                                        </div>
                                        
                                        
                                                              <div class="col-sm-offset-2  col-sm-5">
                                        <label>Upload Profile Image *</label>
                                        
                                           <input type="file"  class='form-control' name="upload" required>
                                                   
                                        </div>
                                                           
                                        </div>
                                        
                                        
                                        
                                        <hr>
                                        
                                        <div class="row" style="margin-bottom: 0px;">
                                        
                                        <div class="col-sm-offset-1 col-sm-6 text-right">
                                        <button class="btn btn-primary btn-lg"  name='submit' type="submit" >Add Service</button>
                                        
                                        </div>
                                        </div>
        		                    </form>
                                </div>
                                
                                
                            </div>   
                </div>
            </div>
        </div> 

        <div id="AddJob" class="tab-pane fade">
		
            <div class="row">

                <div class="col-md-12">
                    <div class="panel panel-inverse">
                        <div class="panel-heading">
                   
                            <h2 class="panel-title" style="font-size: 20px;">Add Job</h2>
                        </div>
                        <div class="panel-body">
                            
                            <form class="reg-page" name='addjob' enctype="multipart/form-data" action='addjob' method='post' onsubmit="return confirm('Please Check the details before submition, You can not modify it!');">
		
                            <div class="row" style="margin-bottom: 30px;">
            		            <div class="col-sm-5"> 
            		            
            		                <label for="stitle">Job Title: </label>
					
                                    <input class="form-control"  name='title'  id="title" type='text' style='text-align:center;' placeholder='Title' required>
            		            </div>
            		            <div class="col-sm-5">
					                <label for="jdescs">Job Description: </label>
					                <textarea  name='jdescs' class="form-control" id="jdescs" style='text-align:center;height: 40px;' required ></textarea>
				                </div>
            		        </div>
		
                            <div class="row" style="margin-bottom: 30px;">
                                <div class="col-sm-5">
				                <label for ="jtype">Job Type: </label>
			
					            <select name='jtype'  id ="jtype" class="form-control" style="width: 200px;" required>
						 
        						  <option>Choose Job Type</option>
        						  <option value="Full Time">Full Time</option>
        						  <option value="Part Time">Part Time</option>
						 
						        </select>
			   
			                </div>
                                <div class="col-sm-5">
                                <label for="location">Job Location: </label>
					            <input class="form-control"  name='location'  id="location" type='text' style='text-align:center;' placeholder='Location' required>
				 
				 
                            </div>	
		                    </div>
    		   
                            <div class="row" style="margin-bottom: 30px;">
    		                    <div class="col-sm-5">
    			                    <label for="experience">Experience: </label>
    					
    					
    					            <input class="form-control"  name='experience'  id="experience" type='text' style='text-align:center;' placeholder='Experience' required>
    		
    			               </div>
    			                <div class="col-sm-5">
    			                    
    					            <label for="salary">Salary: </label>
    					
    					
    					            <input class="form-control"  name='salary'  id="salary" type='text' style='text-align:center;' placeholder='Salary' required>
    				            </div>
		                    </div>
		   
                        <div class="row" style="margin-bottom: 30px;">
		                    <div class="col-sm-5">
			    
                            
                                <label for ="upload">Upload Job Image: </label>				
                                <input type="file"  class="form-control" style="width: 195px;" name="upload" id ="upload" required>
		                    </div>
			
		                </div>
                        <div class="row" style="margin-bottom: 0px;">
                            <div class="col-md-offset-1 col-sm-6 text-right">
						        <button  class="btn btn-primary btn-lg" name='submit' type="submit" >Add Job</button>					
                        </div>
		                </div>
                        </form>
                            
                        </div>
                    </div>
            </div>
            </div>
        
        </div>
        
        <div id="Feedbacktab" class="tab-pane fade">
            
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-inverse">
                                <div class="panel-heading">
                                    <h2 class="panel-title" style="font-size:20px;">Provide Feedback</h2>
                                </div>
                                <div class="panel-body">
                                    
                                    <?php include'feedbacktab_data.php';?>
                                    
                                    <form class="reg-page" name='client_feedback' enctype="multipart/form-data" action='client_feedback' method='post' onsubmit="return confirm('Thank you for the feedback!');" style="background-color: #fff;margin-bottom: 5px;padding-top: 30px;">
                         
										 <div class="row" style="margin-bottom:30px;">
											 <div class="col-sm-5">
												 <lebel>Job Title *</lebel>
												 <input class="form-control" name="fbjtitle" type="text" style="text-align:center;" placeholder="Job Title" required>
											 </div>
											 
											 <div class="col-sm-5">
												 <lebel>Employee Name *</lebel><br>
												 
												 <select name="fbename">

                                                    <?php while($row1 = mysqli_fetch_array($result1)):;?>
                                        
                                                    <option value="<?php echo $row1[0];?>"><?php echo $row1[0];?></option>
                                        
                                                    <?php endwhile;?>
                                        
                                                </select>
												 
												 <!--
												 <input class="form-control" name="fbename" type="text" style="text-align:center;" placeholder="Employee Name" required> 
												 -->
											 </div>
											 
											 <div class="col-sm-5">
												 <lebel>Employee id *</lebel><br>
												 
												 <select name="fbeid">

                                                    <?php while($row2 = mysqli_fetch_array($result2)):;?>
                                        
                                                    <option value="<?php echo $row2[0];?>"><?php echo $row2[0];?></option>
                                        
                                                    <?php endwhile;?>
                                        
                                                </select>
												 
		
											 </div>
											 
											 
											 
											 <div class="col-sm-5">
												 <lebel>Employer id *</lebel><br>
												 
												 <select name="fbemployer_id">

                                                    <?php while($row3 = mysqli_fetch_array($result3)):;?>
                                        
                                                    <option value="<?php echo $row3[0];?>"><?php echo $row3[0];?></option>
                                        
                                                    <?php endwhile;?>
                                        
                                                </select>
												 
		
											 </div>
											 
											 
											 
											 
										 </div>
										 
										 <div class="row" style="margin-bottom:30px;">
											 
											 <div class="col-sm-5">
												  <lebel>Provide Rating *</lebel>
												  <label for="input-1" class="control-label"></label>
                                            <input id="input-1" name='rating' class="rating rating-loading" value="0" data-min="0" data-max="5" data-step="0.5" data-size="xs">

												  
												   <!-- MyProfile strt 
												  <select name='rating' class="form-control">
													 
													  <option value = "1Star">One Star</option>
													  <option value = "2Star">Two Star</option>
													  <option value = "3Star">Three Star</option>
													  <option value = "4Star">Four Star</option>
													  <option value = "5Star">Five Star</option>
													 
													 
												  </select>
												  
												   MyProfile strt -->
											 </div>
											 
											 <div class="col-sm-5">
												 <lebel>Feedback in Depth  *</lebel>
												  <textarea class="form-control" name="fbdesc" type ="text" style= "text-align:center;" placeholder="Feedback in detail" required></textarea>
												 
											 </div>
											 
											 
										 </div>
										 
										 <hr>
										 
										 <div class="row" style="margin-bottom: 0px;">
                           
                            <div class="col-md-5 text-right">
                                <button class="btn btn-primary btn-lg" name="submit" type="submit">Submit</button>
                            </div>
                             
                             
                         </div>
                         
									</form>
                                </div>
                                
                                
                            </div>   
                </div>
            </div>




            
        </div>
  
   
    <!-- MyProfile strt -->
  
        <div id="MyProfile" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
	 
	        <div class="row" style="    margin-top: 20px;margin-bottom: 20px;">
		     <div class="col-md-offset-4 col-md-6" >
			    
			      <h2  style="font-size: 20px;">My Profile</h2>
			 
			 </div>
			 
		   </div>
                      
                         
       
		
           
			   <?php 
   
								
					include 'connect.php';
							   
						if (mysqli_connect_errno()) 
						{
							printf("Connect failed: %s\n", mysqli_connect_error());
							exit();
						}
									  
								  
								
								  
						$sql = "SELECT `id`, `firstname`, `lastname`, `email`, `password`, `type`, `mobileno`, `createdate`, `modified` FROM `users` WHERE     `email` = '".$Email."' ";

						if ($result = mysqli_query($con,$sql))
						{
									
							if (mysqli_num_rows($result) == 1)
								{
									  
									$row = mysqli_fetch_assoc($result);
											
									$FirstName= $row['firstname'];
									$LastName= $row['lastname'];									
									$mobile= $row['mobileno'];
									
										
										 
							echo"
																
									<table class='table table-hover table-striped' style='background-color: #337ab7;margin-top: 10px;'>
										<thead>
											<th style='background-color: #088895;color: #FFF;'>First Name</th>
											<th style='background-color: #088895;color: #FFF;'>Last Name</th>
											<th style='background-color: #088895;color: #FFF;'>Mobile</th>
											<th style='background-color: #088895;color: #FFF;'>Email</th>
											
																		
										</thead>
										<tbody>
											<tr  style='font-size: 15px;color: #000;'>
												<td>$FirstName</td>
												<td>$LastName</td>
												<td>$mobile</td>
												<td>$Email</td>
												
											</tr>
																		
										</tbody>
									</table>";
										 
									
									  } 
									}
								
								?>
			
		
     </div>
    </div>
   </div><!-- MyProfile Close -->
   
   <!-- EditProfile Start -->
        <div id="EditProfile" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
	 
	 
	    <div class="row" style="    margin-top: 20px;margin-bottom: 20px;">
		     <div class="col-md-offset-4 col-md-6" >
			    
			      <h2  style="font-size: 20px;">Edit Profile</h2>
			 
			 </div>
			 
		</div>
                       
                         
         
			
			    <?php include'editprofile_employeer.php';?>
			 
			  <form class="reg-page" name='Edit_profile' enctype="multipart/form-data" action='updateprofile_employer' method='post' onsubmit="return confirm('Please Check the details after submition, You can not modify it?');" style="background-color: #fff;margin-bottom: 5px;padding-top: 30px;">
						
								
									
									
				<div class="row" style="margin-bottom: 30px;">
									
					<div class="col-sm-5">
						<label>Edit The First Name *</label>											
											
					 <input class='form-control' name='fname'  type='text' style='text-align:center;' value='<?php echo "$FirstName"; ?>' >
					</div>
				    <div class="col-sm-offset-2 col-sm-5">
					   <label>Edit The Last Name *</label>
											
					 <input class='form-control'  name="lname" placeholder='Last Name'  type='text' style='text-align:center;' value='<?php echo "$LastName"; ?>'>
					</div>										
				</div>
									
				<div class="row" style="margin-bottom: 30px;">
									
					<div class=" col-sm-5">
						<label>Email Id *</label>											
						<input type='text' name='Email' value='<?php echo $Email;?>' class='form-control' style='text-align:center;'    readonly>										            
					</div>
										
					<div class="col-sm-offset-2 col-sm-5">
						<label>Edit The Password  *</label>										
											
					    <input class='form-control' name='pass'  placeholder='Password' type='text' style='text-align:center;'	value='<?php echo "$passworde"; ?>'  >
										            
					</div>			
				</div>
									
									
			    <div class="row" style="margin-bottom: 30px;">
					 <div class="col-sm-5">
						<label>Edit  The  Mobile  Number *</label>
												
					   <input class='form-control' name='mobileu'  placeholder='Mobile Number' 
					   type='text' style='text-align:center;'  value='<?php echo "$mobilenum"; ?>' >
					 </div>
				
										
				</div>
				
							
				<hr>

						<div class="row" style="margin-bottom: 0px;">
											
							<div class="col-sm-offset-1 col-sm-6 text-right">
							<button class="btn btn-primary btn-lg"  name='submit' type="submit" >UPDATE</button>
												
							</div>
						</div>
			  </form>
			 
			 
			

    </div>
   </div><!-- EditProfile Close -->
  
  
  
 </div><!-- All Tabs Close -->
	
   
  </div>
 </div>
</div>

        <div class="modal fade" id="myModal" role="dialog">
 <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
  <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
           <div class="row">
			  <div class="col-md-5  toppad  pull-left">
				   
                <h3>Edit Post Details</h3>
			
			  </div>
		   </div>
        </div>
    <div class="modal-body">
		
     
	<div id="PostShow" align="center">
	</div>
       
    </div>
      
   </div>
  </div>
 </div>


    </div>
</body>

    <!--   Core JS Files   -->
   
   
	
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>

	
    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

   
    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js"></script>
	
	
    <!--star rating -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-star-rating/4.0.2/js/star-rating.min.js"></script>

	
	
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="assets/plugins/jquery/jquery-1.9.1.min.js"></script>
	<script src="assets/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
	<script src="assets/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	
	<!--[if lt IE 9]>
		<script src="assets/crossbrowserjs/html5shiv.js"></script>
		<script src="assets/crossbrowserjs/respond.min.js"></script>
		<script src="assets/crossbrowserjs/excanvas.min.js"></script>
	<![endif]-->
	
	

</html>