<?php
   @session_start();

  if(isset($_SESSION['UserName']) && isset($_SESSION['Email']))
	 {
				 $UserName = $_SESSION['UserName'];
				 $Email= $_SESSION['Email'];
				
				 
				   $_SESSION['UserName'] =$UserName;
                   $_SESSION['Email'] =$Email;
					
	}
				
	else 
	{  
				 header('location: ../login.php');
	}
			
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	
	<link rel="icon" type="image/png" href="../images/favicon.png">
	<meta http-equiv="Refresh" content="3;url=superuser" />
    
	<title> Super User Dashboard</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS  
      
	-->
	<link href="assets/css/custom.css" rel="stylesheet"/>
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>
    
	
	<link href="assets/css/jquery.fileupload.css" rel="stylesheet"/>
    <link href="assets/css/jquery.fileupload-ui.css" rel="stylesheet"/>
     
	 
	 

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
    <style>
	  
			  .controls label {
			display: inline-block;
			width: 90px;
			height: 20px;
			text-align: center;
			vertical-align: top;
			padding-top: 40px;
		}
		.controls input {
			display: block;
			margin: 0 auto -40px;
		}
	  
	</style>
	  
	<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>  
	  
   	  
	  
	<script>
    $(document).ready(function() 
	{
        function disableBack() 
		{ window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt)
		{ 
		   if (evt.persisted) disableBack() 
		}
    });
   </script>
	
    <link href="assets/css/style.min.css" rel="stylesheet" /> 
	<link href="assets/css/style-responsive.min.css" rel="stylesheet" />
	<link href="assets/css/theme/default.css" rel="stylesheet" id="theme" />
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
	<link href="assets/plugins/bootstrap-wizard/css/bwizard.min.css" rel="stylesheet" />
	<link href="assets/plugins/parsley/src/parsley.css" rel="stylesheet" />
	<!-- ================== END PAGE LEVEL STYLE ================== -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	
	<!-- ================== END BASE JS ================== -->  
	 
   <!-- <script type="text/javascript" src="../js/validation.js"></script> 
	<script type="text/javascript" src="../js/alertify.min.js"></script> 
	<link rel="stylesheet" href="../css/alertify.core2.css">
	<link rel="stylesheet" href="../css/alertify.default.css"> -->
  
</head>
<body>

<div class="wrapper">
    <div class="sidebar" style='background-color:#303840;width:250px;'  >

   
    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                   Super User Dashboard
                </a>
            </div>

              <ul class="nav">
              
				<li class="active"><a data-toggle="tab" href="#AddServices">
                        <p>Add Services</p></a></li>
						
						
						
			     <li><a data-toggle="tab" href="#AddJob">
                        <p>Add Job</p></a></li>
						
				 <li><a data-toggle="tab" href="#AddEmployee">
                        <p>Add Employee</p></a></li>		
						
				<li><a data-toggle="tab" href="#AllServices">
                        <p>All Services</p></a></li>  		
		

				 <li><a data-toggle="tab" href="#AllEmps">
                        <p>All Employees</p></a></li>

                						
						
				
				<li><a data-toggle="tab" href="#MyProfile"> 
                        <p>My Profile</p></a></li>
				
            </ul>
    	</div>
    </div>

<div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    

                    <ul class="nav navbar-nav navbar-right">
                        
						<li>
                            <a href="#">
                               <i  style="font-size: 28px;float: left;margin-right: 5px;line-height: 30px;width: 30px;text-align: center;    margin-top: -6px;"></i> <?php echo"$UserName"; ?>
							   
                            </a>
                        </li>						
						
                        <li>
                            <a href="#">
							<i  style="font-size: 28px;float: left;margin-right: 5px;line-height: 30px;width: 30px;text-align: center;    margin-top: -6px;"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


<div class="content">
 <div class="container-fluid">
  <div class="tab-content">
   
   <div id="PostFreeAds" class="tab-pane fade in active">
		
    <div class="row">

    <div class="col-md-12" style="padding: 20px;">
        <?php
		
		     include 'connect.php';
		
             if (isset($_POST['submit'])) 
				{    
									
					if (empty($_POST['title']) || empty($_POST['location']) || empty($_POST['jdescs'])|| empty($_POST['jtype'])) 
						  
					{
						$error = "Details are invalid";
						echo"$error";
										
					}
									
					else
						{ 
									 
							$title=$_POST['title'];
							$location=$_POST['location'];
							$descs=$_POST['jdescs'];
							$type=$_POST['jtype'];
							$experience=$_POST['experience'];
							$salary=$_POST['salary'];
							
							 
							if(isset($_FILES['upload']))
							{
									
									// file name, type, size, temporary name
									$file_name = $_FILES['upload']['name'];
									$file_type = $_FILES['upload']['type'];
									$file_tmp_name = $_FILES['upload']['tmp_name'];
									$file_size = $_FILES['upload']['size'];
							 
									// target directory
									$target_dir = "upload/";
									
									$created = date('Y-m-d H:i:s');   
								
									// uploding file
									if(move_uploaded_file($file_tmp_name,$target_dir.$file_name))
									{
											
										
									$filename= $target_dir.$file_name;		
													 
							        $query= "INSERT INTO `jobs`(`id`, `title`, `location`, `image`, `description`, `type`, `salary`, `experience`, `createdate`, `modified`)
				  	                       VALUES (null,'".$title."','".$location."','".$filename."','".$descs."','".$type."','".$salary."','".$experience."','".$created."','".$created."')";
							
							
							          $con->query($query) or die("Error : ".mysqli_error($con));
													  
							              echo"<h5 style='text-align:center;'> Your job detail has stored successfully!</h5> "; 
										
									}
									
								}
								
													   
						}
							
											  
					}   
									
					else{
										
							echo"Error";
										
					}
					
			mysqli_close($con);		
								  
		?>                
            
     </div>
    </div>
   </div> <!-- post close -->
  
  </div><!-- All Tabs Close -->
	
   </div>
  </div>
 </div>
</div>


</body>

    <!--   Core JS Files   -->
   
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>

	
    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

   
    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js"></script>

	

	
	
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="assets/plugins/jquery/jquery-1.9.1.min.js"></script>
	<script src="assets/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
	<script src="assets/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<!--[if lt IE 9]>
		<script src="assets/crossbrowserjs/html5shiv.js"></script>
		<script src="assets/crossbrowserjs/respond.min.js"></script>
		<script src="assets/crossbrowserjs/excanvas.min.js"></script>
	<![endif]-->
	

	
	<!-- ================== END BASE JS ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	<script src="assets/plugins/parsley/dist/parsley.js"></script>
	<script src="assets/plugins/bootstrap-wizard/js/bwizard.js"></script>
	<script src="assets/js/form-wizards-validation.demo.min.js"></script>
	<script src="assets/js/apps.min.js"></script>
	<!-- ================== END PAGE LEVEL JS ================== -->
	
	

</html>
