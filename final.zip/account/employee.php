<?php 
@session_start();



    if(isset($_SESSION['UserName']) && isset($_SESSION['Email']) && isset($_SESSION['type']) && isset($_SESSION['employee'])  )
	 {
				 $UserName = $_SESSION['UserName'];
				 $Email= $_SESSION['Email'];
				  $type= $_SESSION['type'];
				 
				   $_SESSION['UserName'] =$UserName;
                   $_SESSION['Email'] =$Email;
			
	}
				
	else 
	{  
				// header('location: ../login.php');
				session_destroy(); //destroy the session
                header("location:../login.php"); //to redirect back to "index.php" after logging out
                exit();
	}
			 
  
			 
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	
	<link rel="icon" type="image/png" href="../images/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title> Employee Dashboard</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

 
	<link href="assets/css/custom.css" rel="stylesheet"/>
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>
    
	
	

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
   
    <style>
	  
			  .controls label {
			display: inline-block;
			width: 90px;
			height: 20px;
			text-align: center;
			vertical-align: top;
			padding-top: 40px;
		}
		.controls input {
			display: block;
			margin: 0 auto -40px;
		}
	  
	</style>
	
	
	  
	<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>  
	
	
	
    <link href="assets/css/style.min.css" rel="stylesheet" /> 
	<link href="assets/css/style-responsive.min.css" rel="stylesheet" />
	<link href="assets/css/theme/default.css" rel="stylesheet" id="theme" />
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
	<link href="assets/plugins/bootstrap-wizard/css/bwizard.min.css" rel="stylesheet" />
	<link href="assets/plugins/parsley/src/parsley.css" rel="stylesheet" />
	<!-- ================== END PAGE LEVEL STYLE ================== -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	
	<!-- ================== END BASE JS ================== -->  
  
</head>
<body>

<div class="wrapper">
    <div class="sidebar" style='background-color:#303840;width:250px;' >

   
    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                   Employee Dashboard
                </a>
            </div>

            <ul class="nav">
              
				<!--<li class="active"><a data-toggle="tab" href="#AddServices"><i class="pe-7s-upload"></i>
                        <p>Add Services</p></a></li> -->
				
				<li class="active"><a data-toggle="tab" href="#MyProfile"> <i class="pe-7s-user"></i>
                        <p>My Profile</p></a></li>
				
               <!-- <li> <a href="#" data-toggle="modal" data-target="#myModal"><i class="pe-7s-user"></i>
                        <p>My Profile</p></a></li>-->				
						
				<li><a data-toggle="tab" href="#EditProfile"><i class="pe-7s-config"></i>
                        <p>Edit Profile</p></a></li> 	
				
               
				
            </ul>
    	</div>
    </div>

<div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    

                    <ul class="nav navbar-nav navbar-right">
                        
						<li>
                            <a href="#">
                               <i class="pe-7s-user" style="font-size: 28px;float: left;margin-right: 5px;line-height: 30px;width: 30px;text-align: center;    margin-top: -6px;"></i> <?php echo"$UserName"; ?>
							   
                            </a>
                        </li>
						
						
                        <li>
                            <a href="logout">
							<i class="pe-7s-back" style="font-size: 28px;float: left;margin-right: 5px;line-height: 30px;width: 30px;text-align: center;    margin-top: -6px;"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


<div class="content">
 <div class="container-fluid">
 <div class="tab-content">
   
 <!-- post close -->
  
  
  
  
  
  
  
  
   
  
   
    <!-- MyProfile strt -->
  
   <div id="MyProfile" class="tab-pane fade in active">
		
    <div class="row">

     <div class="col-md-12">
	 
	      <div class="row" style="    margin-top: 20px;margin-bottom: 20px;">
		     <div class="col-md-offset-4 col-md-6" >
			    
			      <h2  style="font-size: 20px;">My Profile</h2>
			 
			 </div>
			 
		</div>
                       
       
			   <?php 
   
								
					include 'connect.php';
							   
						if (mysqli_connect_errno()) 
						{
							printf("Connect failed: %s\n", mysqli_connect_error());
							exit();
						}
									  
								  
								
								  
						$sql = "SELECT `id`, `firstname`, `lastname`, `email`, `password`, `type`, `mobileno`, `designation`, `skills`, `gender`, `qualification`, `experience`, `description`,`profileImage`,`address` FROM `users` WHERE     `email` = '".$Email."' ";

						if ($result = mysqli_query($con,$sql))
						{
									
							if (mysqli_num_rows($result) == 1)
								{
									  
									$row = mysqli_fetch_assoc($result);
											
									$FirstName= $row['firstname'];
									$LastName= $row['lastname'];									
									$mobile= $row['mobileno'];
									$designation=$row['designation'];
									$skills=$row['skills'];
									$qualification=$row['qualification'];
									$experience=$row['experience'];
									$description=$row['description'];
									$profileImage=$row['profileImage'];
									$address=$row['address'];
									
										
										 
							echo"<br><div class='row'>
							      <div class='col-md-3'>
							         <img src='$profileImage'  height=150px; width=150px/>
								  </div>
								  
								  <div class='col-md-7'>
							          <table class='table table-hover table-striped' style='background-color: #337ab7;margin-top: 10px;'>
										
									
										<tbody>
										  <tr  style='font-size: 15px;color: #000;'>
												<td>First Name</td>
												<td>$FirstName</td>
										  </tr>
                                          <tr  style='font-size: 15px;color: #000;'>
												<td>Last Name</td>
												<td>$LastName</td>
										  </tr>	
                                           <tr  style='font-size: 15px;color: #000;'>
												<td>Mobile</td>
												<td>$mobile</td>
										  </tr>
                                          <tr  style='font-size: 15px;color: #000;'>
												<td>Email</td>
												<td>$Email</td>
										  </tr>	

                                          <tr  style='font-size: 15px;color: #000;'>
												<td>Designation</td>
												<td>$designation</td>
										  </tr>
										  
										   <tr  style='font-size: 15px;color: #000;'>
												<td>Address</td>
												<td>$address</td>
										  </tr>
                                          <tr  style='font-size: 15px;color: #000;'>
												<td>Skills</td>
												<td>$skills</td>
										  </tr>	
                                           <tr  style='font-size: 15px;color: #000;'>
												<td>Qualification</td>
												<td>$qualification</td>
										  </tr>
                                          <tr  style='font-size: 15px;color: #000;'>
												<td>Experience</td>
												<td>$experience</td>
										  </tr>	
                                           <tr  style='font-size: 15px;color: #000;'>
												<td>Description</td>
												<td>$description</td>
										  </tr>											  
														
										</tbody>
									</table>
								  </div>
								</div>";
										 
									
									  } 
									}
								
								?>
			
		
     </div>
    </div>
   </div><!-- MyProfile Close -->
   
   <!-- EditProfile Start -->
   <div id="EditProfile" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
	 
	    <div class="row" style="    margin-top: 20px;margin-bottom: 20px;">
		     <div class="col-md-offset-4 col-md-6" >
			    
			      <h2  style="font-size: 20px;">My Profile</h2>
			 
			 </div>
			 
		</div>
                       
     
			
			    <?php include'editprofile.php';?>
			 
			  <form class="reg-page" name='Edit_profile' enctype="multipart/form-data" action='updateprofile' method='post' onsubmit="return confirm('Please Check the details after submition, You can not modify it?');" style="background-color: #fff;margin-bottom: 5px;padding-top: 30px;">
						
								
									
									
				<div class="row" style="margin-bottom: 30px;">
									
					<div class="col-sm-5">
						<label>Edit The First Name <span class="color-red">*</span></label>											
											
					 <input class='form-control' name='fname'  type='text' style='text-align:center;' value='<?php echo "$FirstName"; ?>' >
					</div>
				    <div class="col-sm-offset-2 col-sm-5">
					   <label>Edit The Last Name <span class="color-red">*</span></label>
											
					 <input class='form-control'  name="lname" placeholder='Last Name'  type='text' style='text-align:center;' value='<?php echo "$LastName"; ?>'>
					</div>										
				</div>
									
				<div class="row" style="margin-bottom: 30px;">
									
					<div class=" col-sm-5">
						<label>Email Id <span class="color-red">*</span></label>											
						<input type='text' name='Email' value='<?php echo $Email;?>' class='form-control' style='text-align:center;'    readonly>										            
					</div>
										
					<div class="col-sm-offset-2 col-sm-5">
						<label>Edit The Password  <span class="color-red">*</span></label>										
											
					    <input class='form-control' name='pass'  placeholder='Password' type='text' style='text-align:center;'	value='<?php echo "$passworde"; ?>'  >
										            
					</div>			
				</div>
									
									
			    <div class="row" style="margin-bottom: 30px;">
					 <div class="col-sm-5">
						<label>Edit  The  Mobile  Number <span class="color-red">*</span></label>
												
					   <input class='form-control' name='mobileu'  placeholder='Mobile Number' 
					   type='text' style='text-align:center;'  value='<?php echo "$mobilenum"; ?>' >
					 </div>
					 
					 <div class="col-sm-offset-2 col-sm-5">
						<label>Edit Designation  <span class="color-red">*</span></label>										
											
					    <input class='form-control' name='designation'  placeholder='Designation' type='text' style='text-align:center;'	value='<?php echo "$designation"; ?>'  >
										            
					</div>			
				</div>
				
				 <div class="row" style="margin-bottom: 30px;">
					  
					 
					 <div class=" col-sm-5">
						<label>Edit Qualification  <span class="color-red">*</span></label>	
						<select class='form-control' name='qualification'>
						   <option><?php echo "$qualification"; ?></option>
						   <option value="10">10<sup>th</sup></option>
						   <option value="Degree">Degree</option>
						   <option value="Master Degree">Master Degree</option>						
						</select>
										            
					</div>
                    <div class="col-sm-offset-2 col-sm-5">
						<label>Edit  Experience <span class="color-red">*</span></label>
			
					   <textarea class='form-control' name='experience' style='text-align:center;' ><?php echo "$experience"; ?></textarea>
					   
					 </div>  
                    					
				</div>
				 <div class="row" style="margin-bottom: 30px;">
				 
					  <div class="col-sm-5">
						<label>Edit Description  <span class="color-red">*</span></label>										
											
					    <textarea class='form-control' name='desc' style='text-align:center;' ><?php echo "$desc"; ?></textarea>
										            
					 </div> 
					 
					 
					 <div class="col-sm-offset-2 col-sm-5">
						<label>Edit  Gender <span class="color-red">*</span></label>
												
					    <br>
					   
					  <label class="checkbox-inline"> <input type="radio"  name='gender' value="Male" <?php echo ($gender=='Male')?"checked":"" ;?>>  &nbsp;&nbsp; Male </label>
                      <label class="checkbox-inline"><input type="radio"   name='gender'  value="Female" <?php echo ($gender=='Female')?"checked":"" ;?>>&nbsp;&nbsp; Female </label>
					   
					   
					 </div>
					 
					 		
				</div><br>
				
				 <div class="row" style="margin-bottom: 30px;">
				 
					  <!--<div class="col-sm-5">
						<label>Upload Profile Image  <span class="color-red">*</span></label>										
											
					    <input type="file"  class='form-control' name="upload">
										            
					 </div>  -->
					 
					  <div class=" col-sm-5">
						<label>Edit Address  <span class="color-red">*</span></label>										
											
					    <input class='form-control' name='address'  placeholder='Address' type='text' style='text-align:center;'	
						value='<?php echo "$address"; ?>'  >
										            
					</div>	
					 
					 
					 
					 		
				</div>
				
				<br>
				
				 <div class="row" style="margin-bottom: 30px;">
					 <div class="col-sm-12">
						<label>Selected  Skills <span class="color-red">*</span></label>
						<ul>
						<?php 
						
						$N = count($skills_arr);
						
						if($N<=0)
						{
								
								echo("<li>None of the skills were checked</li>");
						}else{
								
							
								for($i=0; $i < $N; $i++)
								{
									
									echo("<li>".$skills_arr[$i] . "</li>");
								}
							}
						
						
						?>
							</ul>
						
					 </div>					 
								
				</div>
				
				 <div class="row" style="margin-bottom: 30px;">
					 <div class="col-sm-12">
						<label>Edit  Skills <span class="color-red">*</span></label>
							
						<label class="checkbox-inline"><input  name="skills[]" type="checkbox" value="Photoshop">Adobe Photoshop</label>
						<label class="checkbox-inline"><input  type="checkbox" name="skills[]" value="PHP">PHP</label>
						<label class="checkbox-inline"><input  type="checkbox" name="skills[]" value="Wordpress">Wordpress</label>
						<label class="checkbox-inline"><input  type="checkbox" name="skills[]" value="SEO">SEO</label>
						<label class="checkbox-inline"><input  type="checkbox" name="skills[]" value="Java">JAVA Developer</label>
						<label class="checkbox-inline"><input  type="checkbox" name="skills[]" value="MySQL">MySQL</label>					   
					   
					 </div>					 
								
				</div>
				
							
				<hr>

						<div class="row" style="margin-bottom: 0px;">
											
							<div class="col-sm-offset-1 col-sm-6 text-right">
												<button class="btn btn-primary btn-lg"  name='submit' type="submit" >UPDATE</button>
												
							</div>
						</div>
			  </form>
			 
			 
		
     </div>
    </div>
   </div><!-- EditProfile Close -->
  
  
  
 </div><!-- All Tabs Close -->
	
   </div>
  </div>
 </div>
</div>

<div class="modal fade" id="myModal" role="dialog">
 <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
  <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
           <div class="row">
			  <div class="col-md-5  toppad  pull-left">
				   
                <h3>Edit Post Details</h3>
			
			  </div>
		   </div>
        </div>
    <div class="modal-body">
		
     
	<div id="PostShow" align="center">
	</div>
       
    </div>
      
   </div>
  </div>
 </div>



</body>

    <!--   Core JS Files   -->
   
   
	
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>

	
    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

   
    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js"></script>

	

	
	
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="assets/plugins/jquery/jquery-1.9.1.min.js"></script>
	<script src="assets/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
	<script src="assets/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	
	<!--[if lt IE 9]>
		<script src="assets/crossbrowserjs/html5shiv.js"></script>
		<script src="assets/crossbrowserjs/respond.min.js"></script>
		<script src="assets/crossbrowserjs/excanvas.min.js"></script>
	<![endif]-->
	
	

</html>