var xmlHttp_sc
function showSubCat(str)
{ 
xmlHttp_sc=GetXmlHttpObject()
if (xmlHttp_sc==null)
 {
 alert ("Browser does not support HTTP Request")
 return
 }
var url="showsubcat.php"
url=url+"?q="+str
url=url+"&sid="+Math.random()
xmlHttp_sc.onreadystatechange=stateChanged_sc 
xmlHttp_sc.open("GET",url,true)
xmlHttp_sc.send(null)
}function stateChanged_sc() 
{ 
if (xmlHttp_sc.readyState==4 || xmlHttp_sc.readyState=="complete")
 { 
 document.getElementById("txtSubCat").innerHTML=xmlHttp_sc.responseText 
 } 
}function GetXmlHttpObject()
{
var xmlHttp_sc=null;
try
 {
 // Firefox, Opera 8.0+, Safari
 xmlHttp_sc=new XMLHttpRequest();
 }
catch (e)
 {
 //Internet Explorer
 try
  {
  xmlHttp_sc=new ActiveXObject("Msxml2.XMLHTTP");
  }
 catch (e)
  {
  xmlHttp_sc=new ActiveXObject("Microsoft.XMLHTTP");
  }
 }
return xmlHttp_sc;
}