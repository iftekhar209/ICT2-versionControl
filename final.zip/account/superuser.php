<?php 
@session_start();



    if(isset($_SESSION['UserName']) && isset($_SESSION['Email'])  && isset($_SESSION['type']) && isset($_SESSION['superuser'])  )
	 {
				 $UserName = $_SESSION['UserName'];
				 $Email= $_SESSION['Email'];
				  $type= $_SESSION['type'];
				 
				   $_SESSION['UserName'] =$UserName;
                   $_SESSION['Email'] =$Email;
				
	}
				
	else 
	{  
				// header('location: ../login.php');
				
                session_destroy(); //destroy the session
                header("location:../login.php"); //to redirect back to "index.php" after logging out
                exit();
	}
			 
  
			 
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	
	<link rel="icon" type="image/png" href="../images/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title> Super User Dashboard</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS  
      
	-->
	<link href="assets/css/custom.css" rel="stylesheet"/>
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>
    
	
	<link href="assets/css/jquery.fileupload.css" rel="stylesheet"/>
    <link href="assets/css/jquery.fileupload-ui.css" rel="stylesheet"/>
     
	 
	 

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
    <style>
	  
			  .controls label {
			display: inline-block;
			width: 90px;
			height: 20px;
			text-align: center;
			vertical-align: top;
			padding-top: 40px;
		}
		.controls input {
			display: block;
			margin: 0 auto -40px;
		}
	  
	</style>
	
	
	  
	<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>  
	
	
	
    <link href="assets/css/style.min.css" rel="stylesheet" /> 
	<link href="assets/css/style-responsive.min.css" rel="stylesheet" />
	<link href="assets/css/theme/default.css" rel="stylesheet" id="theme" />
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL STYLE ==================-->
	<link href="assets/plugins/bootstrap-wizard/css/bwizard.min.css" rel="stylesheet" />
	<link href="assets/plugins/parsley/src/parsley.css" rel="stylesheet" />
	<!-- ================== END PAGE LEVEL STYLE ================== -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="assets/plugins/pace/pace.min.js"></script>
	<!-- ================== END BASE JS ================== -->  
	
	<!--<script type="text/javascript" src="hide_show.js"></script> 
	 
    <script type="text/javascript" src="../js/validation.js"></script> 
	<script type="text/javascript" src="../js/alertify.min.js"></script> 
	<link rel="stylesheet" href="../css/alertify.core2.css">
	<link rel="stylesheet" href="../css/alertify.default.css"> -->
  
</head>
<body>

<div class="wrapper">
    <div class="sidebar" style='background-color:#303840;width:250px;'>

   
    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                   Super User Dashboard
                </a>
            </div>

            <ul class="nav">
              
				<li class="active"><a data-toggle="tab" href="#AddServices">
                        <p>Add Services</p></a></li>
						
				<li><a data-toggle="tab" href="#AddEmployee">
                        <p>Add Employee</p></a></li>
						
			     <li><a data-toggle="tab" href="#AddJob">
                        <p>Add Job</p></a></li>
						
				<li><a data-toggle="tab" href="#AllServices">
                        <p>All Services</p></a></li>  		
		

				 <li><a data-toggle="tab" href="#AllEmps">
                        <p>All Employees</p></a></li>			
						
				
				<li><a data-toggle="tab" href="#MyProfile"> 
                        <p>My Profile</p></a></li>
				
               <!-- <li> <a href="#" data-toggle="modal" data-target="#myModal"><i class="pe-7s-user"></i>
                        <p>My Profile</p></a></li>		-->		
						
				<li><a data-toggle="tab" href="#EditProfile">
                        <p>Edit Profile</p></a></li>
				
               
				
            </ul>
    	</div>
    </div>

<div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    

                    <ul class="nav navbar-nav navbar-right">
                        
						<li>
                            <a href="#">
                                <?php echo"$UserName"; ?>
							   
                            </a>
                        </li>
						
						
                        <li>
                            <a href="logout">
                                Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


<div class="content">
 <div class="container-fluid">
 <div class="tab-content">
   
 <!-- post close -->
  
  
  
  
  
  <div id="AddServices" class="tab-pane fade in active">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel panel-inverse">
		     <div class="panel-heading">
                
                 <h2 class="panel-title" style="font-size: 20px;">Add Service</h2>
            </div>		
            <div class="panel-body">
			
			     
			 
			  <form class="reg-page" name='addservices' enctype="multipart/form-data" action='suser_addservices' method='post' onsubmit="return confirm('Please Check the details after submition, You can not modify it?');" style="background-color: #fff;margin-bottom: 5px;padding-top: 30px;">
						
								
									
									
				<div class="row" style="margin-bottom: 30px;">
									
					<div class="col-sm-5">
						<label>Service Title <span class="color-red">*</span></label>											
											
					 <input class='form-control' name='stitle'  type='text' style='text-align:center;' placeholder='Title' required>
					</div>
				     <div class="col-sm-offset-2 col-sm-5">
						<label>Service Description <span class="color-red">*</span></label>
			
					   <textarea class='form-control' name='sdescs' style='text-align:center;' required ></textarea>
					   
					</div>										
				</div>
									
				
				
				 <div class="row" style="margin-bottom: 30px;">				  
					 
					 <div class=" col-sm-5">
						<label>Service Icon <span class="color-red">*</span></label>
			
					     <select name='icon' class="form-control" required>
						  <option>Choose Icon</option>
						  <option value="fa fa-desktop">Application Development</option>
						  <option value="fa fa-bank">Banking</option>
						  <option value="fa fa-users">Staffing</option>
						  <option value="fa fa-bar-chart">Sales & marketing</option>
						  <option value="fa fa-suitcase">Management</option>
						  <option value="fa fa-cogs">Digital Marking</option>
						 
						 </select>
					   
					</div>	
					 
					 
                      <div class="col-sm-offset-2  col-sm-5">
						<label>Upload Profile Image  <span class="color-red">*</span></label>										
											
					    <input type="file"  class='form-control' name="upload" required>
										            
					 </div>					 
                    					
				</div>
				
				
							
				<hr>

				<div class="row" style="margin-bottom: 0px;">
											
							<div class="col-sm-offset-1 col-sm-6 text-right">
								<button class="btn btn-primary btn-lg"  name='submit' type="submit" >Add Service</button>
												
							</div>
				</div>
			  </form>
			  
			</div>
		</div>
     </div>
    </div>
   </div> 
  
 
  
   <div id="AddJob" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel panel-inverse">
		     <div class="panel-heading">
                
                 <h2 class="panel-title" style="font-size: 20px;">Add Job</h2>
            </div>		
            <div class="panel-body">
			
			     
			 
			  <form class="reg-page" name='addservices' enctype="multipart/form-data" action='suser_addjob' method='post' onsubmit="return confirm('Please Check the details after submition, You can not modify it?');" style="background-color: #fff;margin-bottom: 5px;padding-top: 30px;">
						
								
									
									
				<div class="row" style="margin-bottom: 30px;">
									
					<div class="col-sm-5">
						<label>Job Title <span class="color-red">*</span></label>											
											
					 <input class='form-control' name='title'  type='text' style='text-align:center;' placeholder='Title' required>
					</div>
				    <div class="col-sm-offset-2 col-sm-5">
					   <label>Location <span class="color-red">*</span></label>
											
					 <input class='form-control'  name="location" placeholder='Location'  type='text' style='text-align:center;' required>
					</div>										
				</div>
									
				
				
				 <div class="row" style="margin-bottom: 30px;">				  
					 
					 
                    <div class="col-sm-5">
						<label>Job Description <span class="color-red">*</span></label>
			
					   <textarea class='form-control' name='jdescs' style='text-align:center;' required ></textarea>
					   
					 </div>

                     <div class="col-sm-offset-2  col-sm-5">
						<label>Job Type  <span class="color-red">*</span></label>										
											
					  
						
						 <select name='jtype' class="form-control" required>
						  <option>Choose Job Type</option>
						  <option value="Full Time">Full Time</option>
						  <option value="Part Time">Part Time</option>
						 
						 </select>
										            
					 </div> 					 
                    					
				</div>
				
				<div class="row" style="margin-bottom: 30px;">				  
					 
					 
                    <div class="col-sm-5">
						<label>Experience <span class="color-red">*</span></label>
			
					      <input   class='form-control' name="experience" placeholder='Experience'  type='text' style='text-align:center;' required >
					   
					 </div>

                     <div class="col-sm-offset-2  col-sm-5">
						<label>Salary <span class="color-red">*</span></label>										
											
					    <input   class='form-control' name="salary" placeholder='Salary'  type='text' style='text-align:center;' required >
										            
					 </div> 					 
                    					
				</div>
				
				
				 <div class="row" style="margin-bottom: 30px;">				  
					 

                     <div class="col-sm-5">
						<label>Upload Profile Image  <span class="color-red">*</span></label>										
											
					    <input type="file"  class='form-control' name="upload" required>
										            
					 </div> 					 
                    					
				</div>
				
							
				<hr>

				<div class="row" style="margin-bottom: 0px;">
											
							<div class="col-sm-offset-1 col-sm-6 text-right">
								<button class="btn btn-primary btn-lg"  name='submit' type="submit" >Add Job</button>
												
							</div>
				</div>
			  </form>
			  
			</div>
		</div>
     </div>
    </div>
   </div>
   
   
   
   <div id="AddEmployee" class="tab-pane fade">
       <div class="row">
           <div class="col-md-12">
               
               <div class = "panel panel-inverse">
                   <div class="panel-heading">
                
                 <h2 class="panel-title" style="font-size: 20px;">Add Employee</h2>
            </div>
                   <div class="panel-body">
                       
                       <form class="reg-page" name='addemployee' enctype="multipart/form-data" action='addemployee' method='post' onsubmit="return confirm('Please Check the details after submition, You can not modify it?');" style="background-color: #fff;margin-bottom: 5px;padding-top: 30px;">
                           
                           
                           <div class="row" style="margin-bottom:30px;">
                               
                               <div class="col-sm-5">
                                   <label>First Name *</label>
                                   <input class='form-control' name='fname' type='text' style="text-align:center;" placeholder='First Name' required>
                               </div>
                               
                               <div class="col-sm-offset-2 col-sm-5">
                                   <label>Last Name *</label>
                                   <input class='form-control' name='lname' type='text' style="text-align:center;" placeholder='Last Name' required>
                                   
                               </div>
                               
                           </div>
                           
                           <div class="row" style="margin-bottom:30px;">
                               
                               <div class="col-sm-5">
                                   <label>Email *</label>
                                   <input class='form-control' name='email' type='email' style="text-align:center;" placeholder='Email' required>
                               </div>
                               
                               <div class="col-sm-offset-2 col-sm-5">
                                   <label>Mobile *</label>
                                   <input class='form-control' name='mobile' type='text' style="text-align:center;" placeholder='Mobile' required>
                                   
                               </div>
                               
                               
                           </div>
                           
                            <div class="row" style="margin-bottom:30px;">
                                
                                <div class="col-sm-5">
                                   <label>Password *</label>
                                   <input class='form-control' name='password' type='password' style="text-align:center;" placeholder='Password' required>
                               </div>
                               
                               <div class="col-sm-offset-2 col-sm-5">
                                   <label>Confirm Password *</label>
                                   <input class='form-control' name='confirmpassword' type='password' style="text-align:center;" placeholder='Confirm Password' required>
                                   
                               </div>
                                
                                
                                
                            </div>
                            
                            <div class="row" style="margin-bottom: 0px;">
                                <div class="col-sm-offset-1 col-sm-6 text-right">
                                    
                                    	<button class="btn btn-primary btn-lg"  name='submit' type="submit" >Add Employee</button>
                                    
                                </div>
                                
                            </div>
                           
                           
                       </form>
                       
                       
                   </div>
               </div>
               
           </div>
       </div>
       

       
       
       
   </div>


	
	
	
	 <div id="AllEmps" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel panel-inverse">
		     <div class="panel-heading">
               
                 <h2 class="panel-title" style="font-size: 20px;">All Employees</h2>
            </div>		
            <div class="panel-body" style="padding-top:10px;">
			   <?php

			    include("connect.php");
								
							
								
				$result=mysqli_query($con,"SELECT `id`, `firstname`, `lastname`, `email` , `designation`, `skills`,  `experience`, `description`, `profileImage`, `address` FROM `users` where `type` ='employee'");
				
				
			
				 echo "<table class='table table-hover table-striped' style='background-color: #337ab7;margin-top: 10px;'>
										<thead>
											<th style='background-color: #088895;color: #FFF;'>Name</th>
											<th style='background-color: #088895;color: #FFF;'>Email</th>
											<th style='background-color: #088895;color: #FFF;'>Desg</th>
											<th style='background-color: #088895;color: #FFF;'>Skills</th>
											<th style='background-color: #088895;color: #FFF;'>Experience</th>
											
				                            <th style='background-color: #088895;color: #FFF;'>Remove</th>
																		
										</thead><tbody>";


						while($data = mysqli_fetch_row($result))
						{   
							
							
							
						echo "<tr  style='font-size: 15px;color: #000;'>";
						
						echo "<td align=center>$data[1] $data[2]</td>";
						echo "<td align=center>$data[3]</td>";
						echo "<td align=center>$data[4]</td>";
						echo "<td align=center>$data[5]</td>";
						echo "<td align=center>$data[6]</td>";
						echo"<td align=center><form action='remove_emp.php' method='post'>				                    
											<input type=hidden name='id' value=".$data[0]." >
											<i class='btn-sm float-xs-right waves-input-wrapper waves-effect' style='color: rgb(8, 8, 8);font-size: 15px;font-weight: bold;'>
											 <input type='submit' name='submit' id='submit' value='Remove' class='waves-button-input' style='border: solid 3px #f1ece7;background: #ff0b25;border-radius: 6px;color: #fff;'>
										   </i></form></td>";	

																   
								   
									
									echo "</tr>";  
							
						
						}
						echo "</tbody></table></div>";
						
						
						

	            mysqli_close($con);					
                ?>
			</div>
		</div>
     </div>
    </div>
   
   
  
  
   <div id="AllServices" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel panel-inverse">
		     <div class="panel-heading">
               
                 <h2 class="panel-title" style="font-size: 20px;">All Services</h2>
            </div>		
            <div class="panel-body" style="padding-top:10px;">
			   <?php

			    include("connect.php");
								
							
								
				$result=mysqli_query($con,"SELECT `title`, `description`, `id` FROM `services`");
				
				
			
				 echo "<table class='table table-hover table-striped' style='background-color: #337ab7;margin-top: 10px;'>
										<thead>
											<th style='background-color: #088895;color: #FFF;'>Title</th>
											<th style='background-color: #088895;color: #FFF;'>Description</th>
											
				                            <th style='background-color: #088895;color: #FFF;'>Remove</th>
																		
										</thead><tbody>";


				while($data = mysqli_fetch_row($result))
				{   
					
					
					
				echo "<tr  style='font-size: 15px;color: #000;'>";
				
				echo "<td align=center>$data[0]</td>";
				echo "<td align=center>$data[1]</td>";
                echo"<td align=center><form action='remove_service.php' method='post'>				                    
									<input type=hidden name='id' value=".$data[2]." >
									<i class='btn-sm float-xs-right waves-input-wrapper waves-effect' style='color: rgb(8, 8, 8);font-size: 15px;font-weight: bold;'>
                                     <input type='submit' name='submit' id='submit' value='Remove' class='waves-button-input' style='border: solid 3px #f1ece7;background: #ff0b25;border-radius: 6px;color: #fff;'>
                                   </i></form></td>";	

                           								   
						   
							
							echo "</tr>";  
							
						
						}
						echo "</tbody></table></div>";
						
						
						

	            mysqli_close($con);					
                ?>
			</div>
		</div>
     </div>
    </div>
   
  
  
  
  
  
   
    <!-- MyProfile strt -->
  
   <div id="MyProfile" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel panel-inverse">
		     <div class="panel-heading">
               
                 <h2 class="panel-title" style="font-size: 20px;">My Profile</h2>
            </div>		
            <div class="panel-body" style="padding-top:10px;">
			   <?php 
   
								
					include 'connect.php';
							   
						if (mysqli_connect_errno()) 
						{
							printf("Connect failed: %s\n", mysqli_connect_error());
							exit();
						}
									  
								  
								
								  
						$sql = "SELECT `id`, `firstname`, `lastname`, `email`, `password`, `type`, `mobileno`, `createdate`, `modified` FROM `users` WHERE     `email` = '".$Email."' ";

						if ($result = mysqli_query($con,$sql))
						{
									
							if (mysqli_num_rows($result) == 1)
								{
									  
									$row = mysqli_fetch_assoc($result);
											
									$FirstName= $row['firstname'];
									$LastName= $row['lastname'];									
									$mobile= $row['mobileno'];
									
										
										 
							echo"
																
									<table class='table table-hover table-striped' style='background-color: #337ab7;margin-top: 10px;'>
										<thead>
											<th style='background-color: #088895;color: #FFF;'>First Name</th>
											<th style='background-color: #088895;color: #FFF;'>Last Name</th>
											<th style='background-color: #088895;color: #FFF;'>Mobile</th>
											<th style='background-color: #088895;color: #FFF;'>Email</th>
											
																		
										</thead>
										<tbody>
											<tr  style='font-size: 15px;color: #000;'>
												<td>$FirstName</td>
												<td>$LastName</td>
												<td>$mobile</td>
												<td>$Email</td>
												
											</tr>
																		
										</tbody>
									</table>";
										 
									
									  } 
									}
								
								?>
			</div>
		</div>
     </div>
    </div>
   </div><!-- MyProfile Close -->
   
   <!-- EditProfile Start -->
   <div id="EditProfile" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel panel-inverse">
		     <div class="panel-heading">
                
                 <h2 class="panel-title" style="font-size: 20px;">Edit Profile</h2>
            </div>		
            <div class="panel-body">
			
			    <?php include'editprofile_employeer.php';?>
			 
			  <form class="reg-page" name='Edit_profile' enctype="multipart/form-data" action='updateprofile_employer' method='post' onsubmit="return confirm('Please Check the details after submition, You can not modify it?');" style="background-color: #fff;margin-bottom: 5px;padding-top: 30px;">
						
								
									
									
				<div class="row" style="margin-bottom: 30px;">
									
					<div class="col-sm-5">
						<label>Edit The First Name <span class="color-red">*</span></label>											
											
					 <input class='form-control' name='fname'  type='text' style='text-align:center;' value='<?php echo "$FirstName"; ?>' >
					</div>
				    <div class="col-sm-offset-2 col-sm-5">
					   <label>Edit The Last Name <span class="color-red">*</span></label>
											
					 <input class='form-control'  name="lname" placeholder='Last Name'  type='text' style='text-align:center;' value='<?php echo "$LastName"; ?>'>
					</div>										
				</div>
									
				<div class="row" style="margin-bottom: 30px;">
									
					<div class=" col-sm-5">
						<label>Email Id <span class="color-red">*</span></label>											
						<input type='text' name='Email' value='<?php echo $Email;?>' class='form-control' style='text-align:center;'    readonly>										            
					</div>
										
					<div class="col-sm-offset-2 col-sm-5">
						<label>Edit The Password  <span class="color-red">*</span></label>										
											
					    <input class='form-control' name='pass'  placeholder='Password' type='text' style='text-align:center;'	value='<?php echo "$passworde"; ?>'  >
										            
					</div>			
				</div>
									
									
			    <div class="row" style="margin-bottom: 30px;">
					 <div class="col-sm-5">
						<label>Edit  The  Mobile  Number <span class="color-red">*</span></label>
												
					   <input class='form-control' name='mobileu'  placeholder='Mobile Number' 
					   type='text' style='text-align:center;'  value='<?php echo "$mobilenum"; ?>' >
					 </div>
				
										
				</div>
				
							
				<hr>

						<div class="row" style="margin-bottom: 0px;">
											
							<div class="col-sm-offset-1 col-sm-6 text-right">
												<button class="btn btn-primary btn-lg"  name='submit' type="submit" >UPDATE</button>
												
							</div>
						</div>
			  </form>
			 
			 
			
			</div>
		</div>
     </div>
    </div>
   </div><!-- EditProfile Close -->
  
  
  
 </div><!-- All Tabs Close -->
	
   </div>
  </div>
 </div>
</div>

<div class="modal fade" id="myModal" role="dialog">
 <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
  <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
           <div class="row">
			  <div class="col-md-5  toppad  pull-left">
				   
                <h3>Edit Post Details</h3>
			
			  </div>
		   </div>
        </div>
    <div class="modal-body">
		
     
	<div id="PostShow" align="center">
	</div>
       
    </div>
      
   </div>
  </div>
 </div>



</body>

    <!--   Core JS Files   -->
   
   
	
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>

	
    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

   
    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js"></script>

	

	
	
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="assets/plugins/jquery/jquery-1.9.1.min.js"></script>
	<script src="assets/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
	<script src="assets/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	
	<!--[if lt IE 9]>
		<script src="assets/crossbrowserjs/html5shiv.js"></script>
		<script src="assets/crossbrowserjs/respond.min.js"></script>
		<script src="assets/crossbrowserjs/excanvas.min.js"></script>
	<![endif]-->
	
	

</html>