<?php
@session_start(); // Starting Session
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) 
{
	include 'connect.php';
	
	
	
	
	
	if (empty($_POST['email']) || empty($_POST['password'])) 
	{
	$error = "Email or Password is invalid";

	echo"$error";
	}


	else
	{ 

     

		// Define $username and $password
		$email=mysqli_real_escape_string($con, $_POST['email']);
		$password=mysqli_real_escape_string($con, $_POST['password']);


		
		   
		// To protect MySQL injection for Security purpose
		$email = stripslashes($email);
		$password = stripslashes($password);
		
		$pass=md5($password);

		//$pass=$password;
		
		

		$query = mysqli_query($con,"SELECT `id`, `firstname`, `lastname`, `email`, `type` FROM `users`  WHERE  password='$pass'  AND email='$email'");
		 
		if($query)
		 {
			
			
				if(mysqli_num_rows($query) >= 1)
				 {
					
					
					$row=mysqli_fetch_assoc($query);
					
					$FirstName =$row["firstname"];
					$LastName =$row["lastname"];
					
					
					$_SESSION['UserName'] ="$FirstName"."$LastName";
					$_SESSION['Email'] =$row["email"];
					
					/*  remove start  
					echo "<script>alert('You are Successfully logged in')</script> ";
					 
				 	echo "<script>window.location.href='../index'</script>";
							 exit; 
							 
					  remove after  */		 
					
				  	
					if($row["type"]=="employer")
					{
						
						$_SESSION['employeer'] ="$FirstName";
						$_SESSION['Email'] =$row["email"];
						$_SESSION['type'] =$row["type"];
						
					    echo "<script>window.location.href='employeer'</script>";
					    exit; 
					}
					else if($row["type"]=="employee")
					{    
						  $_SESSION['employee'] ="$FirstName";
						  $_SESSION['Email'] =$row["email"];
						  $_SESSION['type'] =$row["type"];
						  echo "<script>window.location.href='employee'</script>";
						  exit; 
					}
					else 
					{
						  $_SESSION['superuser'] ="$FirstName";
						  $_SESSION['Email'] =$row["email"];
						  $_SESSION['type'] =$row["type"];
						  echo "<script>window.location.href='superuser'</script>";
						  exit;
					}
					
					
					 
				
				 }
				
				else
				 {
					 echo "<script>alert('Enter valid User namme and password  or  Register again')</script> ";
					 
					 echo "<script>window.location.href='../login'</script>";
							 exit; 
				 }


			}

		else { echo"fail";} 

		mysqli_close($con); // Closing Connection
	}
}
?>