<?php

	header('Content-type: application/json');
	$status = array(
		'type'=>'success',
		'message'=>'Thank you for contact us. As early as possible  we will contact you '
	);

    $name = @trim(stripslashes($_POST['name'])); 
    $email = @trim(stripslashes($_POST['email']));   
    $title = @trim(stripslashes($_POST['title'])); 
	$type = @trim(stripslashes($_POST['type'])); 
    $jobcategory = @trim(stripslashes($_POST['jobcategory']));
	$description = @trim(stripslashes($_POST['description']));

     
     echo"$name"."\n";	 
     echo"$email"."\n";
     echo"$title"."\n";	 
     echo"$jobcategory"."\n";	
     echo"$type"."\n";	 
     echo"$description"."\n";	 
	
	
	
  
    $email_from = $email;
    $email_to = 'iftekharbappi209@gmail.com';
   

    $body = 'Name: ' . $name . "\n\n" . 'Email: ' . $email . "\n\n" . 'Subject: ' . $title . "\n\n". 'Skills: ' . $jobcategory . "\n\n" .'Type: ' . $type . "\n\n" . 'Message: ' . $description;

    $success = @mail($email_to, $subject, $body, 'From: <'.$email_from.'>');

   
	header('location: about');
    die;
	
	?>