<?php

session_start(); 

// if the sign up form was submitted
if($_POST)
{
 
    
 
    if( !empty($_POST['mobile'])|| !empty($_POST['password'])|| !empty($_POST['confirmpassword'])|| !empty($_POST['email'])|| !empty($_POST['fname'])|| !empty($_POST['lname']))  
    {
 
           include 'connect.php';
		
		              $Email=$_POST["email"];
 
                      $FirstName=$_POST["fname"];
			          $LastName=$_POST["lname"];
					 		  
					  $Email=$_POST["email"];
					  $mobile=$_POST["mobile"];
					 
					  
                      //date_default_timezone_set('Asia/Calcutta');         
					  $created = date('Y-m-d H:i:s');   
					 
				     
					  $password1=$_POST["password"];
			          $conpassword=$_POST["confirmpassword"];
                      $type=$_POST["type"];
					  
					 $image="../img/avatar.jpg";
					  

                   
				
			   if ($password1==$conpassword)
               {	
				  
 
                    $sql= "INSERT INTO `users`(`id`, `firstname`, `lastname`, `email`, `password`, `type`, `mobileno`, `createdate`, `modified`, `profileImage`)  
					VALUES (null,'".$FirstName."','".$LastName."','".$Email."','".$password1."','".$type."','".$mobile."','".$created."','".$created."','".$image."')";

	                 mysqli_query($con,$sql);
	       
			       
			
			            $_SESSION['Email'] =$Email;
						$_SESSION['UserName'] ="$FirstName "."$LastName";
			  
			      echo "<script>window.location.href='../login'</script>";
                  exit; 
			
               
			   }

               else 
               {
	            
				   echo"<script type='text/javascript'>
					alert('Password should not be matched');
					  </script> ";
					
				  echo "<script>window.location.href='../register'</script>";
				  exit; 				
				
               }			   
					
           
 
 
 
    } ///
	
	 else
	{
	    echo "Invalid details";
    }	
 
}
 

?>