
// This function is responsible for checking which button is pressed. If user clicks the right mouse button then an alert is coming out that "Right Click Not Allowed!".
function whichButton(event)
{
 if (event.button==2)//For right click
 {
  alert("Right Click Not Allowed!");
 }
}
// This function is responsible for checking which key is being pressed. If user presses ctrl key then the an alert is coming out that "Sorry, this functionality is disabled.".
function noCTRL(e)
{
 var code = (document.all) ? event.keyCode:e.which;
 var msg = "You trying to paste something ?Sorry, this functionality is disabled to prevent spam.";
 if (parseInt(code)==17) // This is the Key code for CTRL key
 {
  alert(msg);
  window.event.returnValue = false;
 }
}
