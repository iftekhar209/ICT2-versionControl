
function fillChars(chr,cnt) {
var s = '';
for (var i=0; i<cnt; i++) { s += chr; }
return s;
}

var BadWords =['sex','Sex','escorts','escort','fuck','Viagra','sexy','Sexy','Fuck','shit','Shit','Escorts','Escort','adults','adult','Adults','Adult','porn','Porn','ass','asshole','pills','penis','Penis','call girls','call girl','naked','breast','Beautiful Model','beautiful model','viagra','Pills','fucker','pussy','Pussy','gay','lesbian'];

function RemoveProfanity() {
var badWordPos = 0;
var str = document.getElementById('textarea2').value;
var str1 = document.getElementById('listingname').value;
str = str.replace(/r?n/g,'n');
str1 = str1.replace(/r?n/g,'n');
var rg;
for (var i=0; i<BadWords.length; i++) {
rg = new RegExp("\s*" + BadWords[i] + "\s*","ig")
str = str.replace(rg,fillChars('*',BadWords[i].length)+' ');
str1 = str1.replace(rg,fillChars('*',BadWords[i].length)+' ');
}
document.getElementById('textarea2').value= str;
document.getElementById('listingname').value= str1;
}
