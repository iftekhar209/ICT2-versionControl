<?php 
@session_start();



    if(isset($_SESSION['UserName']) && isset($_SESSION['Email'])  && isset($_SESSION['type']) && isset($_SESSION['superuser'])  )
	 {
				 $UserName = $_SESSION['UserName'];
				 $Email= $_SESSION['Email'];
				  $type= $_SESSION['type'];
				 
				   $_SESSION['UserName'] =$UserName;
                   $_SESSION['Email'] =$Email;
				
	}
				
	else 
	{  
				// header('location: ../login.php');
				
                session_destroy(); //destroy the session
                header("location:../login.php"); //to redirect back to "index.php" after logging out
                exit();
	}
			 
  
			 
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	
	<link rel="icon" type="image/png" href="../images/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title> Super User Dashboard</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

 
	<link href="assets/css/custom.css" rel="stylesheet"/>
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>
    
	
	

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
   
    <style>
	  
			  .controls label {
			display: inline-block;
			width: 90px;
			height: 20px;
			text-align: center;
			vertical-align: top;
			padding-top: 40px;
		}
		.controls input {
			display: block;
			margin: 0 auto -40px;
		}
	  
	</style>
	
	
	  
	<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>  
	
	
	
    <link href="assets/css/style.min.css" rel="stylesheet" /> 
	<link href="assets/css/style-responsive.min.css" rel="stylesheet" />
	<link href="assets/css/theme/default.css" rel="stylesheet" id="theme" />
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
	<link href="assets/plugins/bootstrap-wizard/css/bwizard.min.css" rel="stylesheet" />
	<link href="assets/plugins/parsley/src/parsley.css" rel="stylesheet" />
	<!-- ================== END PAGE LEVEL STYLE ================== -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	
	<!-- ================== END BASE JS ================== -->  
	
  
</head>
<body>

<div class="wrapper">
    <div class="sidebar" style='background-color:#303840;width:250px;'  >

   
    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                   Super User Dashboard
                </a>
            </div>

            <ul class="nav">
              
				<li class="active"><a data-toggle="tab" href="#AddServices">
                        <p>Add Services</p></a></li>
						
						
						
			     <li><a data-toggle="tab" href="#AddJob">
                        <p>Add Job</p></a></li>
						
				<li><a data-toggle="tab" href="#AllServices">
                        <p>All Services</p></a></li>  		
		

				 <li><a data-toggle="tab" href="#AllEmps">
                        <p>All Employees</p></a></li>

                 <li><a data-toggle="tab" href="#AddEmployee">
                        <p>Add Employee</p></a></li>						
						
				
				<li><a data-toggle="tab" href="#MyProfile"> 
                        <p>My Profile</p></a></li>
				
               <!-- <li><a data-toggle="tab" href="#EditProfile"><i class="pe-7s-config"></i>
                        <p>Edit Profile</p></a></li>	-->		
						
				
				
               
				
            </ul>
    	</div>
    </div>

<div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    

                    <ul class="nav navbar-nav navbar-right">
                        
						<li>
                            <a href="#">
                               <i  style="font-size: 28px;float: left;margin-right: 5px;line-height: 30px;width: 30px;text-align: center;    margin-top: -6px;"></i> <?php echo"$UserName"; ?>
							   
                            </a>
                        </li>
						
						
                        <li>
                            <a href="logout">
							<i  style="font-size: 28px;float: left;margin-right: 5px;line-height: 30px;width: 30px;text-align: center;    margin-top: -6px;"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


<div class="content">
 <div class="container-fluid">
 <div class="tab-content">
   
 <!-- post close -->
  
  
  
  
  
  <div id="AddServices" class="tab-pane fade in active">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel">
		     <div class="panel-heading">
                
                 <h2 style="font-size: 20px;">Add Service</h2>
            </div>		
            <div class="panel-body">
			
			     
			 
			  <form class="reg-page" name='addservices' enctype="multipart/form-data" action='suser_addservices' method='post' onsubmit="return confirm('Please Check the details after submition, You can not modify it?');" style="background-color: #fff;margin-bottom: 5px;padding-top: 30px;">
						
								
									
									
				<div class="row" style="margin-bottom: 30px;">
									
					<div class="col-sm-5">
						<label>Service Title <span class="color-red">*</span></label>											
											
					 <input  name='stitle'  type='text' style='text-align:center;' placeholder='Title' required>
					</div>
				     <div class="col-sm-offset-2 col-sm-5">
						<label>Service Description <span class="color-red">*</span></label>
			
					   <textarea  name='sdescs' style='text-align:center;' required ></textarea>
					   
					</div>										
				</div>
									
				
				
				 <div class="row" style="margin-bottom: 30px;">				  
					 
					 <div class=" col-sm-5">
						<label>Service Icon <span class="color-red">*</span></label>
			
					     <select name='icon'  required>
						  <option>Choose Icon</option>
						  <option value="fa fa-desktop">Application Development</option>
						  <option value="fa fa-bank">Banking</option>
						  <option value="fa fa-users">Staffing</option>
						  <option value="fa fa-bar-chart">Sales & marketing</option>
						  <option value="fa fa-suitcase">Management</option>
						  <option value="fa fa-cogs">Digital Marking</option>
						 
						 </select>
					   
					</div>	
					 
					 
                      <div class="col-sm-offset-2  col-sm-5">
						<label>Upload Profile Image  <span class="color-red">*</span></label>										
											
					    <input type="file"   name="upload" required>
										            
					 </div>					 
                    					
				</div>
				
				
							
				<hr>

				<div class="row" style="margin-bottom: 0px;">
											
							<div class="col-sm-offset-1 col-sm-6 text-right">
								<button  name='submit' type="submit" >Add Service</button>
												
							</div>
				</div>
			  </form>
			  
			</div>
		</div>
     </div>
    </div>
   </div> 
  
  
 
  
  
   <div id="AddEmployee" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel">
		     <div class="panel-heading">
                
                 <h2 class="panel-title" style="font-size: 20px;">Add Employee</h2>
            </div>		
            <div class="panel-body">
			
			     
			 
			  <form class="reg-page" name='addemployee' enctype="multipart/form-data" action='addemployee.php' method='post' onsubmit="return confirm('Please Check the details after submition, You can not modify it?');" style="background-color: #fff;margin-bottom: 5px;padding-top: 30px;">
						
								
									
									
				<div class="row" style="margin-bottom: 30px;">
									
					<div class="col-sm-5">
						<label>First Name <span class="color-red">*</span></label>											
											
					 <input  name='fname'  type='text' style='text-align:center;' placeholder='First Name' required>
					</div>
				    <div class="col-sm-offset-2 col-sm-5">
					   <label>Last Name <span class="color-red">*</span></label>
											
					 <input   name="lname" placeholder='Last Name'  type='text' style='text-align:center;' required>
					</div>										
				</div>
									
				
				
				 <div class="row" style="margin-bottom: 30px;">				  
					 
					 
                    <div class="col-sm-5">
						<label>Email <span class="color-red">*</span></label>
			
					 <input   name="email" placeholder='Email'  type='text' style='text-align:center;' required>
					   
					 </div>

                      <div class="col-sm-offset-2 col-sm-5">
					   <label>Mobile Number <span class="color-red">*</span></label>
											
					 <input   name="mobile" placeholder='Mobile Number'  type='text' style='text-align:center;' required>
					</div>					 
                    					
				</div>
				
				<div class="row" style="margin-bottom: 30px;">				  
					 
					 
                    <div class="col-sm-5">
						<label>Password <span class="color-red">*</span></label>
			
					      <input    name="password" placeholder='Password'  type='text' style='text-align:center;' required >
					   
					 </div>

                     <div class="col-sm-offset-2  col-sm-5">
						<label>Password Confirmation <span class="color-red">*</span></label>										
											
					    <input    name="confirmpassword" placeholder='Password Confirmation'  type='text' style='text-align:center;' required >
										            
					 </div> 					 
                    					
				</div>
				
				
							
				<hr>

				<div class="row" style="margin-bottom: 0px;">
											
							<div class="col-sm-offset-1 col-sm-6 text-right">
								<button  name='submit' type="submit" >Add Employee</button>
												
							</div>
				</div>
			  </form>
			  
			</div>
		</div>
     </div>
    </div>
   </div>
 
  
   <div id="AddJob" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel">
		     <div class="panel-heading">
                
                 <h2 class="panel-title" style="font-size: 20px;">Add Job</h2>
            </div>		
            <div class="panel-body">
			
			     
			 
			  <form class="reg-page" name='addservices' enctype="multipart/form-data" action='suser_addjob' method='post' onsubmit="return confirm('Please Check the details after submition, You can not modify it?');" style="background-color: #fff;margin-bottom: 5px;padding-top: 30px;">
						
								
									
									
				<div class="row" style="margin-bottom: 30px;">
									
					<div class="col-sm-5">
						<label>Job Title <span class="color-red">*</span></label>											
											
					 <input  name='title'  type='text' style='text-align:center;' placeholder='Title' required>
					</div>
				    <div class="col-sm-offset-2 col-sm-5">
					   <label>Location <span class="color-red">*</span></label>
											
					 <input   name="location" placeholder='Location'  type='text' style='text-align:center;' required>
					</div>										
				</div>
									
				
				
				 <div class="row" style="margin-bottom: 30px;">				  
					 
					 
                    <div class="col-sm-5">
						<label>Job Description <span class="color-red">*</span></label>
			
					   <textarea  name='jdescs' style='text-align:center;' required ></textarea>
					   
					 </div>

                     <div class="col-sm-offset-2  col-sm-5">
						<label>Job Type  <span class="color-red">*</span></label>										
											
					  
						
						 <select name='jtype'  required>
						  <option>Choose Job Type</option>
						  <option value="Full Time">Full Time</option>
						  <option value="Part Time">Part Time</option>
						 
						 </select>
										            
					 </div> 					 
                    					
				</div>
				
				<div class="row" style="margin-bottom: 30px;">				  
					 
					 
                    <div class="col-sm-5">
						<label>Experience <span class="color-red">*</span></label>
			
					      <input    name="experience" placeholder='Experience'  type='text' style='text-align:center;' required >
					   
					 </div>

                     <div class="col-sm-offset-2  col-sm-5">
						<label>Salary <span class="color-red">*</span></label>										
											
					    <input    name="salary" placeholder='Salary'  type='text' style='text-align:center;' required >
										            
					 </div> 					 
                    					
				</div>
				
				
				 <div class="row" style="margin-bottom: 30px;">				  
					 

                     <div class="col-sm-5">
						<label>Upload Profile Image  <span class="color-red">*</span></label>										
											
					    <input type="file"   name="upload" required>
										            
					 </div> 					 
                    					
				</div>
				
							
				<hr>

				<div class="row" style="margin-bottom: 0px;">
											
							<div class="col-sm-offset-1 col-sm-6 text-right">
								<button  name='submit' type="submit" >Add Job</button>
												
							</div>
				</div>
			  </form>
			  
			</div>
		</div>
     </div>
    </div>
   </div>


	
	
	
	 <div id="AllEmps" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel">
		     <div class="panel-heading">
               
                 <h2 class="panel-title" style="font-size: 20px;">All Employees</h2>
            </div>		
            <div class="panel-body" style="padding-top:10px;">
			   <?php

			    include("connect.php");
								
							
								
				$result=mysqli_query($con,"SELECT `id`, `firstname`, `lastname`, `email` , `designation`, `skills`,  `experience`, `description`, `profileImage`, `address` FROM `users` where `type` ='employee'");
				
				
			
				 echo "<table  style='background-color: #337ab7;margin-top: 10px;'>
										<thead><tr style='height:30px;'>
											<th style='background-color: #088895;color: #FFF;width: 120px;padding-left: 10px;'>Name</th>
											<th style='background-color: #088895;color: #FFF;width: 120px;padding-left: 10px;'>Email</th>
											<th style='background-color: #088895;color: #FFF;width: 120px;padding-left: 10px;'>Desg</th>
											<th style='background-color: #088895;color: #FFF;width: 120px;padding-left: 10px;'>Skills</th>
											<th style='background-color: #088895;color: #FFF;width: 120px;padding-left: 10px;'>Experience</th>
											
				                            <th style='background-color: #088895;color: #FFF;'>Remove</th>
																		
										</tr></thead><tbody>";


						while($data = mysqli_fetch_row($result))
						{   
							
							
							
						echo "<tr  style='font-size: 15px;color: #000;'>";
						
						echo "<td align=center>$data[1] $data[2]</td>";
						echo "<td align=center>$data[3]</td>";
						echo "<td align=center>$data[4]</td>";
						echo "<td align=center>$data[5]</td>";
						echo "<td align=center>$data[6]</td>";
						echo"<td align=center><form action='remove_emp.php' method='post'>				                    
											<input type=hidden name='id' value=".$data[0]." >
											<i class='btn-sm float-xs-right waves-input-wrapper waves-effect' style='color: rgb(8, 8, 8);font-size: 15px;font-weight: bold;'>
											 <input type='submit' name='submit' id='submit' value='Remove' class='waves-button-input' style='border: solid 3px #f1ece7;background: #ff0b25;border-radius: 6px;color: #fff;'>
										   </i></form></td>";	

																   
								   
									
									echo "</tr>";  
							
						
						}
						echo "</tbody></table></div>";
						
						
						

	            mysqli_close($con);					
                ?>
			</div>
		</div>
     </div>
    </div>
   
   
  
  
   <div id="AllServices" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel">
		     <div class="panel-heading">
               
                 <h2 class="panel-title" style="font-size: 20px;">All Services</h2>
            </div>		
            <div class="panel-body" style="padding-top:10px;">
			   <?php

			    include("connect.php");
								
							
								
				$result=mysqli_query($con,"SELECT `title`, `description`, `id` FROM `services`");
				
				
			
				 echo "<table  style='background-color: #337ab7;margin-top: 10px;'>
										<thead><tr style='height: 35px;'>
											<th style='background-color: #088895;color: #FFF;padding-left: 10px;width:200px;'>Title</th>
											<th style='background-color: #088895;color: #FFF;'>Description</th>
											
				                            <th style='background-color: #088895;color: #FFF;'>Remove</th>
																		
										</tr></thead><tbody>";


				while($data = mysqli_fetch_row($result))
				{   
					
					
					
				echo "<tr  style='font-size: 15px;color: #000;'>";
				
				echo "<td align=center>$data[0]</td>";
				echo "<td align=center>$data[1]</td>";
                echo"<td align=center><form action='remove_service.php' method='post'>				                    
									<input type=hidden name='id' value=".$data[2]." >
									<i class='btn-sm float-xs-right waves-input-wrapper waves-effect' style='color: rgb(8, 8, 8);font-size: 15px;font-weight: bold;'>
                                     <input type='submit' name='submit' id='submit' value='Remove' class='waves-button-input' style='border: solid 3px #f1ece7;background: #ff0b25;border-radius: 6px;color: #fff;'>
                                   </i></form></td>";	

                           								   
						   
							
							echo "</tr>";  
							
						
						}
						echo "</tbody></table></div>";
						
						
						

	            mysqli_close($con);					
                ?>
			</div>
		</div>
     </div>
    </div>
   
  
  
  
  
  
   
    <!-- MyProfile strt -->
  
   <div id="MyProfile" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel">
		     <div class="panel-heading">
               
                 <h2 class="panel-title" style="font-size: 20px;">My Profile</h2>
            </div>		
            <div class="panel-body" style="padding-top:10px;">
			   <?php 
   
								
					include 'connect.php';
							   
						if (mysqli_connect_errno()) 
						{
							printf("Connect failed: %s\n", mysqli_connect_error());
							exit();
						}
									  
								  
								
								  
						$sql = "SELECT `id`, `firstname`, `lastname`, `email`, `password`, `type`, `mobileno`, `createdate`, `modified` FROM `users` WHERE     `email` = '".$Email."' ";

						if ($result = mysqli_query($con,$sql))
						{
									
							if (mysqli_num_rows($result) == 1)
								{
									  
									$row = mysqli_fetch_assoc($result);
											
									$FirstName= $row['firstname'];
									$LastName= $row['lastname'];									
									$mobile= $row['mobileno'];
									
										
										 
							echo"
																
									<table  style='background-color: #337ab7;margin-top: 10px;'>
										<thead><tr style='height: 40px;'>
											<th style='background-color: #088895;color: #FFF;width: 120px;padding-left: 10px;'>First Name</th>
											<th style='background-color: #088895;color: #FFF;width: 120px;'>Last Name</th>
											<th style='background-color: #088895;color: #FFF;width: 120px;'>Mobile</th>
											<th style='background-color: #088895;color: #FFF;width: 120px;padding-right: 10px;'>Email</th>
											</tr>
																		
										</thead>
										<tbody>
											<tr  style='font-size: 15px;color: #000;'>
												<td style='padding-left: 10px;'>$FirstName</td>
												<td>$LastName</td>
												<td>$mobile</td>
												<td style='padding-right: 10px;'>$Email</td>
												
											</tr>
																		
										</tbody>
									</table>";
										 
									
									  } 
									}
								
								?>
			</div>
		</div>
     </div>
    </div>
   </div><!-- MyProfile Close -->
   
   <!-- EditProfile Start -->
   <div id="EditProfile" class="tab-pane fade">
		
    <div class="row">

     <div class="col-md-12">
                       
                         
        <div class="panel">
		     <div class="panel-heading">
                
                 <h2 class="panel-title" style="font-size: 20px;">Edit Profile</h2>
            </div>		
            <div class="panel-body">
			
			    <?php include'editprofile_employeer.php';?>
			 
			  <form class="reg-page" name='Edit_profile' enctype="multipart/form-data" action='updateprofile_employer' method='post' onsubmit="return confirm('Please Check the details after submition, You can not modify it?');" style="background-color: #fff;margin-bottom: 5px;padding-top: 30px;">
						
								
									
									
				<div class="row" style="margin-bottom: 30px;">
									
					<div class="col-sm-5">
						<label>Edit The First Name <span class="color-red">*</span></label>											
											
					 <input  name='fname'  type='text' style='text-align:center;' value='<?php echo "$FirstName"; ?>' >
					</div>
				    <div class="col-sm-offset-2 col-sm-5">
					   <label>Edit The Last Name <span class="color-red">*</span></label>
											
					 <input   name="lname" placeholder='Last Name'  type='text' style='text-align:center;' value='<?php echo "$LastName"; ?>'>
					</div>										
				</div>
									
				<div class="row" style="margin-bottom: 30px;">
									
					<div class=" col-sm-5">
						<label>Email Id <span class="color-red">*</span></label>											
						<input type='text' name='Email' value='<?php echo $Email;?>'  style='text-align:center;'    readonly>										            
					</div>
										
					<div class="col-sm-offset-2 col-sm-5">
						<label>Edit The Password  <span class="color-red">*</span></label>										
											
					    <input  name='pass'  placeholder='Password' type='text' style='text-align:center;'	value='<?php echo "$passworde"; ?>'  >
										            
					</div>			
				</div>
									
									
			    <div class="row" style="margin-bottom: 30px;">
					 <div class="col-sm-5">
						<label>Edit  The  Mobile  Number <span class="color-red">*</span></label>
												
					   <input  name='mobileu'  placeholder='Mobile Number' 
					   type='text' style='text-align:center;'  value='<?php echo "$mobilenum"; ?>' >
					 </div>
				
										
				</div>
				
							
				<hr>

						<div class="row" style="margin-bottom: 0px;">
											
							<div class="col-sm-offset-1 col-sm-6 text-right">
												<button  name='submit' type="submit" >UPDATE</button>
												
							</div>
						</div>
			  </form>
			 
			 
			
			</div>
		</div>
     </div>
    </div>
   </div><!-- EditProfile Close -->
  
  
  
 </div><!-- All Tabs Close -->
	
   </div>
  </div>
 </div>
</div>

<div class="modal fade" id="myModal" role="dialog">
 <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
  <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
           <div class="row">
			  <div class="col-md-5  toppad  pull-left">
				   
                <h3>Edit Post Details</h3>
			
			  </div>
		   </div>
        </div>
    <div class="modal-body">
		
     
	<div id="PostShow" align="center">
	</div>
       
    </div>
      
   </div>
  </div>
 </div>



</body>

    <!--   Core JS Files   -->
   
   
	
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>


	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="assets/plugins/jquery/jquery-1.9.1.min.js"></script>
	
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	
	<!--[if lt IE 9]>
		<script src="assets/crossbrowserjs/html5shiv.js"></script>
		<script src="assets/crossbrowserjs/respond.min.js"></script>
		<script src="assets/crossbrowserjs/excanvas.min.js"></script>
	<![endif]-->
	
	

</html>