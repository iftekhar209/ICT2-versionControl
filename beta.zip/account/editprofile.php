 <?php include 'connect.php';

			$query = mysqli_query($con,"SELECT `id`, `firstname`, `lastname`, `email`, `password`, `type`, `mobileno`, `designation`, `skills`, `gender`, `qualification`, `experience`, `description`, `profileImage`, `address`, `createdate`, `modified`  FROM `users` WHERE	`email`='$Email'");
		 
		if($query)
		 {
		 
		 
			
				if(mysqli_num_rows($query) > 0)
				{
				  $row=mysqli_fetch_assoc($query);
					
					 $FirstName=$row["firstname"];					
					 $LastName=$row["lastname"];					
					 $passworde=$row["password"];
					 $mobilenum=$row["mobileno"];					
					 $email=$row["email"];
					 $qualification=$row["qualification"];
					 $designation=$row["designation"];
					 $gender=$row["gender"];					
					 $experience=$row["experience"];
					 $desc=$row["description"];
					 $skills=$row["skills"];
					 $skills_arr = explode (",", $skills);
					  $address=$row["address"];
					 
					 
				
				}
				
				
				else
				{   
					 $FirstName='';					
					 $LastName='';					
					 $passworde='';
					 $mobilenum='';
					 $qualification='Choose Qualification';
					 $designation='';
					 $gender='';
					 $desc='';
					 $experience='';
					 $address='';
					
				
					 
				}
		 }	


?>		 
		 