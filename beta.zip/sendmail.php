<?php

	header('Content-type: application/json');
	$status = array(
		'type'=>'success',
		'message'=>'Thank you for contact us. As early as possible  we will contact you '
	);

    $name = @trim(stripslashes($_POST['name'])); 
    $email = @trim(stripslashes($_POST['email']));   
    $subject = @trim(stripslashes($_POST['subject'])); 
    $message = @trim(stripslashes($_POST['message']));

     
     echo"$name"."<br>";	 
     echo"$email";	echo"<br>";
     echo"$subject";echo"<br>";	 
     echo"$message";echo"<br>";	 
	
	
	
  
    $email_from = $email;
    $email_to = 'konarisimhachalam@gmail.com';//  Replace Your email id here 
   

    $body = 'Name: ' . $name . "\n\n" . 'Email: ' . $email . "\n\n" .  "\n\n" . 'Subject: ' . $subject . "\n\n" . 'Message: ' . $message;

    $success = @mail($email_to, $subject, $body, 'From: <'.$email_from.'>');

   
	header('location: contact');
    die;
	
	?>