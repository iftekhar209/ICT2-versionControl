<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Remote Workerss</title>
<!-- Bootstrap stylesheet -->
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<!-- font -->
<link href="https://fonts.googleapis.com/css?family=Libre+Baskerville:400,400i,700%7CSource+Sans+Pro:300,400,600,700" rel="stylesheet"> 
<!-- stylesheet -->
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<link href="css/style_cyan.css" title="style_cyan" rel="alternate stylesheet" type="text/css"/>
<link href="css/style_red.css" title="style_red" rel="alternate stylesheet" type="text/css"/>
<link href="css/style_green.css" title="style_green" rel="alternate stylesheet" type="text/css"/>
<link href="css/style_blue.css" title="style_blue" rel="alternate stylesheet" type="text/css"/>
<!-- font-awesome -->
<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<!-- crousel css -->
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<!--bootstrap select-->
<link href="js/dist/css/bootstrap-select.css" rel="stylesheet" type="text/css" />
</head>
<body>


<!-- header start here-->
	<header>
		<!-- header container start here-->
		<div class="container">
			<div class="row">
				<div class="col-sm-3 col-md-3 col-xs-12">
					<!-- logo start here-->
					<div id="logo">
						<a href="index">
							
							<h2>Remote Workerss</h2>
						</a>
					</div>
					<!-- logo end here-->
				</div>
				<div class="col-sm-3 col-md-3 col-xs-12 visible-xs paddleft">
					<!-- button-login start here -->
					<div class="button-login pull-right">
						<button type="button" class="btn btn-default btn-lg" onclick="location.href='login'">Login</button>
						<button type="button" class="btn btn-primary btn-lg" onclick="location.href='register'">Submit Job</button>
					</div>
					<!-- button-login end here -->
				</div>
			    <div class="col-sm-6 col-md-6 col-xs-12 padd0">
					<!-- menu start here-->
					<nav class="navbar" id="menu">
						<div class="navbar-header">
							<span class="menutext visible-xs">Menu</span>
							<button data-target=".navbar-ex1-collapse" data-toggle="collapse" class="btn btn-navbar navbar-toggle" type="button"><i class="fa fa-bars" aria-hidden="true"></i></button>
						</div>
						<div class="collapse navbar-collapse navbar-ex1-collapse padd0">
							<ul class="nav navbar-nav">
								<li>
									<a  href="index"><span>HOME</span></a>
								</li>
								
					            <li>
						          <a href="services"><span>SERVICES</span></a>
					            </li>
					            <li>
						          <a href="employees"><span>EMPLOYEES</span></a>
					            </li>
								 <li>
						          <a href="carrer"><span>CAREER</span></a>
					            </li>
								
							
							</ul>
						</div>
					</nav>
					<!-- menu end here -->
				</div>
			    <div class="col-sm-3 col-md-3 col-xs-12 hidden-xs">
					<!-- button-login start here -->
					<div class="button-login pull-right">
						<button type="button" class="btn btn-default btn-lg" onclick="location.href='login'">Login</button>
						<button type="button" class="btn btn-primary btn-lg" onclick="location.href='register'">Submit Job</button>
					</div>
					<!-- button-login end here -->
				</div>
			</div>
		</div>
		<!-- header container end here -->
	</header>
<!-- header end here -->

	<div id="jobs">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<!-- about-content start here -->
					<div class="jobs-content">
						<h1>Career</h1>
						<ul class="list-inline">
							<li>
								<a href="index">Home</a>
							</li>
							<li>></li>
							<li>
								<a href="carrer">Career</a>
							</li>
						</ul>
					</div>
				<!-- jobs-content end here -->
				</div>
			</div>
		</div>
	</div>
<!-- jobs end here -->
<!-- job start here -->
	<div id="job">
		<div class="container">
			
			<div class="row">
				
				<div class='col-md-12 col-sm-12 col-xs-12 padd0'>
				
				
				   <?php
				  
						$dir    = "account/upload/";
		   
						$filenames = scandir($dir,SCANDIR_SORT_DESCENDING);

				   
						foreach($filenames as $key=>$filename)
						{
						  get_image_name($filename);
						}
						
						function get_image_name($filename)
				        {
							$dir    = "account/upload/";
							$file=$dir.$filename;
							$image="upload/".$filename;
							
							
							if(is_file ($file))
							{
							
							  
							 
							   include 'account/connect.php';
				   
							   if (mysqli_connect_errno()) 
							   {
								 printf("Connect failed: %s\n", mysqli_connect_error());
								 exit();
							   }
							   
							   
							   
							   $sql = "SELECT `id`, `title`, `location`, `image`, `description`, `type`, `createdate`, `modified` FROM `jobs`  WHERE   `image`= '".$image."' ";
							   
								 if ($result = mysqli_query($con,$sql))
								 {
							           
							
							
								   if (mysqli_num_rows($result) >= 1)
								   {
							  
								     $row = mysqli_fetch_assoc($result);
                                    $id = $row['id'];
									$title = $row['title'];
									$location = $row['location'];
	                                $image = $row['image'];
									$type = $row['type'];									
									$description = substr($row['description'],0, 120);
								 
									
									
									 
									 echo"<div class='col-md-3 col-sm-3 col-xs-12'>
											<div class='product-box'>
												<div class='image'>
													<a href='jobss'>
														<img class='img-responsive' src='".$file."' alt='p1' title='p1' style='height: 150px;width: 262px;'/>
													</a>	
													<div class='buttons'>
														<div class='open-down'>
															<button type='button' class='rotate1'>
																<i class='fa fa-link' aria-hidden='true'></i>
															</button>
															<button type='button' class='rotate1'>
																<i class='fa fa-search' aria-hidden='true'></i>
															</button>
														</div>
													</div>		
												</div>		
												<div class='matter'>
													<h1>$title</h1>
													<ul class='list-inline'>
														<li>
															<a href='#'><i class='fa fa-bookmark' aria-hidden='true'></i>$type</a>
														</li>
														<li>
															<a href='#'><i class='fa fa-map-marker' aria-hidden='true'></i>$location</a>
														</li>
													</ul>
													<p>$description  [...]</p>
												</div>
												<a href='job-details?id=".$id."''><button type='button' class='btn btn-info' >VIEW MORE</button></a>
												<a href='about'><button type='button' class='btn btn-info' >APPLY NOW</button></a>
											</div>
										</div>";
								  
								   }
							     }
									 
							 
							 
							}
							
						}
					  
				  
				   ?>
				
				
				
					
					
				</div>
			</div>
		</div>
	</div>
<!-- job end here -->
<!-- Footer start here -->
	<footer>
		<div class="container">
			<div class="bor col-md-12 col-sm-12 col-xs-12 padd0">
				<div class="col-sm-5 col-md-5 col-xs-12 subscribe">
					<h5>Subscribe Our Newsletter</h5>
					<form name="subscribe">
						<div class="form-group">
							<div class="input-group">
								<input type="text" placeholder="Enter your Email Address" id="subscribe_email1" name="subscribe_email" value="" class="form-control">
								<div class="input-group-btn">
									<button class="btn btn-default btn-lg" type="submit"><i class="fa fa-paper-plane-o" aria-hidden="true"></i> SUBSCRIBE</button>
								</div>
							</div>
						</div>
					</form>
				</div>
				<div class="col-sm-4 col-md-4 col-xs-12 follow">
					<h5>Follow us on</h5>
					<ul class="list-inline socialicon">
						<li>
							<a href="https://www.facebook.com/" target="_blank">
								<i class="fa fa-facebook" aria-hidden="true"></i>
							</a>
						</li>
						<li>
							<a href="https://twitter.com/" target="_blank">
								<i class="fa fa-twitter" aria-hidden="true"></i>
							</a>
						</li>
						<li>
							<a href="https://plus.google.com/" target="_blank">
								<i class="fa fa-google-plus" aria-hidden="true"></i>
							</a>
						</li>
						<li>
							<a href="https://www.instagram.com/" target="_blank">
								<i class="fa fa-instagram" aria-hidden="true"></i>
							</a>
						</li>
						<li>
							<a href="https://in.linkedin.com/" target="_blank">
								<i class="fa fa-linkedin" aria-hidden="true"></i>
							</a>
						</li>	
					</ul>
				</div>
				<div class="col-sm-3 col-md-3 col-xs-12 need">
					<h5>Need Help ?</h5>
					<h6><i class="fa fa-phone" aria-hidden="true"></i> CALL US : <span>1800-0000-1234</span></h6>
				</div>	
			</div>
		
	</footer>

	</div>
<!-- Footer end here -->
<!-- jquery -->
<script src="js/jquery.2.1.1.min.js"></script>
<!-- bootstrap js -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!--bootstrap select-->
<script src="js/dist/js/bootstrap-select.js"></script>
<!-- owlcarousel js -->
<script src="js/owl-carousel/owl.carousel.min.js"></script>
<!--internal js-->
<script src="js/internal.js"></script>
<!-- color switcher
<script src="js/switcher.js"></script>-->
</body>

</html>