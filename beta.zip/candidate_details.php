<?php 
  
   if(isset($_GET["id"]))
    {
       
		$id = $_GET["id"];
      
    } 


      include 'account/connect.php';
				   
			if (mysqli_connect_errno()) 
				{
								 printf("Connect failed: %s\n", mysqli_connect_error());
								 exit();
				}
							   
			 $sql = "SELECT  `id`,`firstname`, `lastname`, `email`, `password`, `type`, `mobileno`, `designation`, `skills`, `gender`, `qualification`, `experience`, `description`, `profileImage`, `address`, `createdate`, `modified` FROM `users`   WHERE   `id`= '".$id."' AND `type`='employee'";
							   
				if ($result = mysqli_query($con,$sql))
				{
							           
							
							
					 if (mysqli_num_rows($result) >= 1)
						{
							  
								    $row = mysqli_fetch_assoc($result);
                                    $id = $row['id'];
									$firstname = $row['firstname'];
									$lastname = $row['lastname'];
	                                $email = $row['email'];
									$address = $row['address'];
									$designation = $row['designation'];									
									$description = $row['description'];
                                    $skills = $row['skills'];
	                                $gender = $row['gender'];
									$qualification = $row['qualification'];
									$experience = $row['experience'];
									$mobile = $row['mobileno'];
									$profileImage = $row['profileImage'];									
						}
				}
				   
			mysqli_close($con);					   
							  
?>



<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Candidate Single-view</title>
<!-- Bootstrap stylesheet -->
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<!-- font -->
<link href="https://fonts.googleapis.com/css?family=Libre+Baskerville:400,400i,700%7CSource+Sans+Pro:300,400,600,700" rel="stylesheet"> 
<!-- stylesheet -->
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<link href="css/style_cyan.css" title="style_cyan" rel="alternate stylesheet" type="text/css"/>
<link href="css/style_red.css" title="style_red" rel="alternate stylesheet" type="text/css"/>
<link href="css/style_green.css" title="style_green" rel="alternate stylesheet" type="text/css"/>
<link href="css/style_blue.css" title="style_blue" rel="alternate stylesheet" type="text/css"/>
<!-- font-awesome -->
<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<!-- crousel css -->
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<!--bootstrap select-->
<link href="js/dist/css/bootstrap-select.css" rel="stylesheet" type="text/css" />
</head>
<body>



<!-- header start here-->
	<header>
		<!-- header container start here-->
		<div class="container">
			<div class="row">
				<div class="col-sm-3 col-md-3 col-xs-12">
					<!-- logo start here-->
					<div id="logo">
						<a href="index">
							
							<h2>Remote Workerss</h2>
						</a>
					</div>
					<!-- logo end here-->
				</div>
				<div class="col-sm-3 col-md-3 col-xs-12 visible-xs paddleft">
					<!-- button-login start here -->
					<div class="button-login pull-right">
						<button type="button" class="btn btn-default btn-lg" onclick="location.href='login'">Login</button>
						<button type="button" class="btn btn-primary btn-lg" onclick="location.href='register'">Submit Job</button>
					</div>
					<!-- button-login end here -->
				</div>
			    <div class="col-sm-6 col-md-6 col-xs-12 padd0">
					<!-- menu start here-->
					<nav class="navbar" id="menu">
						<div class="navbar-header">
							<span class="menutext visible-xs">Menu</span>
							<button data-target=".navbar-ex1-collapse" data-toggle="collapse" class="btn btn-navbar navbar-toggle" type="button"><i class="fa fa-bars" aria-hidden="true"></i></button>
						</div>
						<div class="collapse navbar-collapse navbar-ex1-collapse padd0">
							<ul class="nav navbar-nav">
								<li>
									<a  href="index"><span>HOME</span></a>
								</li>
								
					            <li>
						          <a href="services"><span>SERVICES</span></a>
					            </li>
					            <li>
						          <a href="employees"><span>EMPLOYEES</span></a>
					            </li>
								 <li>
						          <a href="carrer"><span>CAREER</span></a>
					            </li>
								
							
							</ul>
						</div>
					</nav>
					<!-- menu end here -->
				</div>
			    <div class="col-sm-3 col-md-3 col-xs-12 hidden-xs">
					<!-- button-login start here -->
					<div class="button-login pull-right">
						<button type="button" class="btn btn-default btn-lg" onclick="location.href='login'">Login</button>
						<button type="button" class="btn btn-primary btn-lg" onclick="location.href='register'">Submit Job</button>
					</div>
					<!-- button-login end here -->
				</div>
			</div>
		</div>
		<!-- header container end here -->
	</header>
<!-- header end here -->
<!-- jobs start here -->
	<div id="jobs">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<!-- about-content start here -->
					<div class="jobs-content canditate">
						<h1>CANDIDATES</h1>
						<ul class="list-inline">
							<li>
								<a href="index">Home</a>
							</li>
							<li>></li>
							<li>
								<a href="candidate-list-view">Candidates</a>
							</li>
						</ul>
					</div>
				<!-- jobs-content end here -->
				</div>
			</div>
		</div>
	</div>
<!-- jobs end here -->
<!-- job start here -->
	<div id="job">
		<div class="container">
			
				<div class="col-md-12 col-sm-12 col-xs-12">
					<div class="form-horizontal candidate-single" >
						<fieldset>
							<div class="form-group">
								<div class="col-sm-5">
									<img src="account/<?php echo $profileImage?>" alt="my_profile" title="my_profile" class="img-responsive" style="width:370px;height:281px;">
								</div>
								<div class="col-sm-7">
									<div class="matter">
										<label>FULL NAME</label>
										<span><?php echo $firstname ." ".$lastname ?></span>
									</div>	
									<div class="matter">
										<label>GENDER</label>
										<span><?php echo $gender ?></span>
									</div>	
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<div class="matter">
										<label>DATE OF BIRTH</label>
										<span>14 / march / 2017</span>
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<div class="matter">
										<label>Address</label>
										<span><?php echo $address ?></span>
									</div>
								</div>
							</div>
							
							<div class="form-group">
								<div class="col-sm-12">
									<div class="matter">
										<label>MOBILE NUMBER</label>
										<span><?php echo $mobile ?></span>
									</div>
								</div>
							</div>
							
							<div class="form-group">
								<div class="col-sm-12">
									<div class="matter">
										<label>PROFESSIONAL SKILLS</label>
										<span><?php echo $skills ?></span>
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<div class="matter">
										<label>EXPERIENCE</label>
										<span><?php echo $experience ?></span>
									</div>
								</div>
							</div>
							
							<div class="form-group">
								<div class="col-sm-12">
									<div class="matter">
										<label>QUALIFICATION</label>
										<span><?php echo $qualification ?></span>
									</div>
								</div>
							</div>
							
							<div class="form-group">
								<div class="col-sm-12">
									<div class="matter">
										<label>DESCRIPTION</label>
										<span><?php echo $description ?></span>
									</div>
								</div>
							</div>
							<!--<div class="form-group">
								<div class="col-sm-12">
									<div class="matter">
										<label>EDUCATION</label>
										<table class="table">
											<tr>
												<td><b>DEGREE</b></td>
												<td><b>COLLEGE / SCHOOL</b></td>
												<td><b>PASSED YEAR</b></td>
												<td><b>PERCENTAGE %</b></td>
											</tr>
											<tr>
												<td>Master</td>
												<td>Example university</td>
												<td>2015</td>
												<td>65 %</td>
											</tr>
											<tr>
												<td>Bachelor</td>
												<td>Example university</td>
												<td>2013</td>
												<td>75 %</td>
											</tr>
											<tr>
												<td>+2</td>
												<td>Example school</td>
												<td>2010</td>
												<td>80 %</td>
											</tr>
											<tr>
												<td>10th</td>
												<td>Example school</td>
												<td>2008</td>
												<td>85 %</td>
											</tr>
										</table>
									</div>
								</div>
							</div> 
							<div class="form-group">
								<div class="col-sm-12">
									<div class="matter">
										<label>Description</label>
										<table class="table">
											<tr>
												<td>INTERST : </td>
												<td class="bor">Playing Cricket, Football, Hockey, Gym, Reading Books, Watching Movies. </td>
											</tr>
											<tr>
												<td>CAREER : </td>
												<td class="bor">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </td>
											</tr>
										</table>
									</div>
								</div>
							</div>
							<div class="button">
								<div class="pull-left">
									<a href="about" class="btn btn-primary btnus">CONTACT ME</a>
								</div>
								<!--<div class="pull-right">
									<button type="submit" value="Submit" class="btn btn-primary btnus">DOWNLOAD RESUME</button>
								</div>
							</div> -->
						</fieldset>
					</div>
				</div>
				<div class="col-md-12 col-sm-12 col-xs-12 padd0">
					<!-- similar-jobs start here -->
					<div class="similar-candidate">
						<h1>Similar candidates</h1>
						<div class="border"></div>
						<div class="border1"></div>
					</div>
					<!-- similar-jobs end here -->
					 <?php
					 
					 
					    if(isset($_GET["id"]))
						{
						   
							$id = $_GET["id"];
						  
						} 
									  
						$dir    = "account/upload/";
		   
						$filenames = scandir($dir,SCANDIR_SORT_DESCENDING);

				   
						foreach($filenames as $key=>$filename)
						{
						  get_image_name($filename,$id);
						}
						
						function get_image_name($filename,$id)
				        {
							$dir    = "account/upload/";
							$file=$dir.$filename;
							$image="upload/".$filename;
							
							
							if(is_file ($file))
							{
							
							  
							 
							   include 'account/connect.php';
				   
							   if (mysqli_connect_errno()) 
							   {
								 printf("Connect failed: %s\n", mysqli_connect_error());
								 exit();
							   }
							   
							   
							   
							   $sql = "SELECT  `id`,`firstname`, `lastname`, `email`, `password`, `type`, `mobileno`, `designation`, `skills`, `gender`, `qualification`, `experience`, `description`, `profileImage`, `address`, `createdate`, `modified` FROM `users`   WHERE   `profileImage`= '".$image."' AND `type`='employee' AND `id` !='".$id."'";
							   
								 if ($result = mysqli_query($con,$sql))
								 {
							           
							
							
								   if (mysqli_num_rows($result) >= 1)
								   {
							  
								     $row = mysqli_fetch_assoc($result);
                                    $id = $row['id'];
									$firstname = $row['firstname'];
									$lastname = $row['lastname'];
	                                $address = $row['address'];
									$designation = $row['designation'];
									$string = $row['description'];
									$description = substr($row['description'],0, 120);
								 
									
									
									 
									 echo"<div class='col-md-3 col-sm-3 col-xs-12'>
											<div class='product-box candidate'>
												<div class='image'>
													<a href='candidate_details?id=".$id."'>
														<img class='img-responsive' src='".$file."' alt='img1' title='img1'   style='height: 150px;width: 262px;'/>
													</a>	
													<div class='buttons'>
														<div class='open-down'>
															<button type='button' class='rotate1'>
																<i class='fa fa-link' aria-hidden='true'></i>
															</button>
															<button type='button' class='rotate1'>
																<i class='fa fa-search' aria-hidden='true'></i>
															</button>
														</div>
													</div>		
												</div>		
												<div class='matter'>
													<h1>$firstname $lastname 
														<button type='button' class='rotate1'>
															<i class='fa fa-link' aria-hidden='true'></i>
														</button>
													</h1>
													<ul class='list-inline'>
														<li>
															<a href='#'><i class='fa fa-bookmark' aria-hidden='true'></i>$designation</a>
														</li>
														<li>
															<a href='#'><i class='fa fa-map-marker' aria-hidden='true'></i>$address</a>
														</li>
													</ul>
													<p>$description [...]</p>
												</div>
												<a href='candidate_details?id=".$id."'><button type='button' class='btn btn-info' >VIEW MORE</button></a>
												
											</div>
										</div>
									 
									 ";
								  
								   }
							     }
									 
							 
							 
							}
							
						}
					  
				  
				   ?>
					
				
				</div>
			</div>
		</div>
	</div>
<!-- abouts end here -->
<!-- Footer start here -->
<footer>
		<div class="container">
			<div class="bor col-md-12 col-sm-12 col-xs-12 padd0">
				<div class="col-sm-5 col-md-5 col-xs-12 subscribe">
					<h5>Subscribe Our Newsletter</h5>
					<form name="subscribe">
						<div class="form-group">
							<div class="input-group">
								<input type="text" placeholder="Enter your Email Address" id="subscribe_email1" name="subscribe_email" value="" class="form-control">
								<div class="input-group-btn">
									<button class="btn btn-default btn-lg" type="submit"><i class="fa fa-paper-plane-o" aria-hidden="true"></i> SUBSCRIBE</button>
								</div>
							</div>
						</div>
					</form>
				</div>
				<div class="col-sm-4 col-md-4 col-xs-12 follow">
					<h5>Follow us on</h5>
					<ul class="list-inline socialicon">
						<li>
							<a href="https://www.facebook.com/" target="_blank">
								<i class="fa fa-facebook" aria-hidden="true"></i>
							</a>
						</li>
						<li>
							<a href="https://twitter.com/" target="_blank">
								<i class="fa fa-twitter" aria-hidden="true"></i>
							</a>
						</li>
						<li>
							<a href="https://plus.google.com/" target="_blank">
								<i class="fa fa-google-plus" aria-hidden="true"></i>
							</a>
						</li>
						<li>
							<a href="https://www.instagram.com/" target="_blank">
								<i class="fa fa-instagram" aria-hidden="true"></i>
							</a>
						</li>
						<li>
							<a href="https://in.linkedin.com/" target="_blank">
								<i class="fa fa-linkedin" aria-hidden="true"></i>
							</a>
						</li>	
					</ul>
				</div>
				<div class="col-sm-3 col-md-3 col-xs-12 need">
					<h5>Need Help ?</h5>
					<h6><i class="fa fa-phone" aria-hidden="true"></i> CALL US : <span>1800-0000-1234</span></h6>
				</div>	
			</div>
		
	</footer>

	</div>
<!-- Footer end here -->
<!-- jquery -->
<script src="js/jquery.2.1.1.min.js"></script>
<!-- bootstrap js -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!--bootstrap select-->
<script src="js/dist/js/bootstrap-select.js"></script>
<!-- owlcarousel js -->
<script src="js/owl-carousel/owl.carousel.min.js"></script>
<!--internal js-->
<script src="js/internal.js"></script>
<!-- color switcher
<script src="js/switcher.js"></script>-->
</body>


</html>